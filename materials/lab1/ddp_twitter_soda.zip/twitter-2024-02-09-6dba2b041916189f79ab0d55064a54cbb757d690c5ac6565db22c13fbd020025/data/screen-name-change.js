window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1447908998859079690",
      "screenNameChange" : {
        "changedAt" : "2021-10-12T13:03:56.000Z",
        "changedFrom" : "data_soda",
        "changedTo" : "SoDa_nl"
      }
    }
  },
  {
    "screenNameChange" : {
      "accountId" : "1447908998859079690",
      "screenNameChange" : {
        "changedAt" : "2023-09-08T10:37:34.000Z",
        "changedFrom" : "SoDa_nl",
        "changedTo" : "ODISSEI_SoDa"
      }
    }
  }
]