window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Po9rbrLcp2KaIrMKpVKtgDxcLORkRvlYMBMMrMRz",
      "createdAt" : "2023-06-22T13:39:53.242Z",
      "lastSeenAt" : "2023-06-30T10:00:09.684Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "IirmJM4lQSQGemtH1b60I0v8tFG8sW9q5MvLmfsI",
      "createdAt" : "2023-09-13T14:44:57.824Z",
      "lastSeenAt" : "2024-02-08T14:05:25.700Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]