window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1749798952302706904",
      "fullText" : "What's more: in this programme we work together with experts from the Netherlands @eScienceCenter, @statistiekcbs, @centerdata &amp; @SURF_NL.\n\nOur very own Social Data Science Team (@ODISSEI_SoDa) will contribute to the training in various ways.",
      "expandedUrl" : "https://twitter.com/i/web/status/1749798952302706904"
    }
  },
  {
    "like" : {
      "tweetId" : "1749798950352335248",
      "fullText" : "🥁The applications for SICSS-ODISSEI Summer School 2024 are open, apply by February 28.\n\n📍@erasmusuni Rotterdam, 17-28 June\n🐍Python and benchmarking challenge\n🌐 Access to @statistiekcbs Microdata\n\nParticipation is free including accommodation! \nhttps://t.co/uFQuohpLiu",
      "expandedUrl" : "https://twitter.com/i/web/status/1749798950352335248"
    }
  },
  {
    "like" : {
      "tweetId" : "1733102467804529091",
      "fullText" : "🧑🏻‍💻Passionate about citizen science? @ODISSEI_nl  and @ODISSEI_SoDa have produced a small piece of software to correct geospatial sampling bias in citizen science projects using data from OpenStreetMaps. \n\n✨Read the full report  https://t.co/FTmWsKlfuO https://t.co/mw4OjYeKrn",
      "expandedUrl" : "https://twitter.com/i/web/status/1733102467804529091"
    }
  },
  {
    "like" : {
      "tweetId" : "1720016195477233912",
      "fullText" : "@ODISSEI_nl Marketplace continues the introductions of the ODISSEI Facilities and research infrastructure providers.\n\n📍Visit @ODISSEI_SoDa booth to learn more about the Fellowship programme, workshops and research support!\n\n#ODISSEI2023 #socialscience #conference https://t.co/LRSr7BdrAm",
      "expandedUrl" : "https://twitter.com/i/web/status/1720016195477233912"
    }
  },
  {
    "like" : {
      "tweetId" : "1706670056460165438",
      "fullText" : "❗️Only 4 days left to apply for the first deadline of the @ODISSEI_SoDa Fellowship.\n\nThis is a fantastic opportunity for early-career researchers to develop their social science-related projects💻 and become part of the @ODISSEI_nl community.\n\nApply now👉🏻 https://t.co/y8EE1BLWxj",
      "expandedUrl" : "https://twitter.com/i/web/status/1706670056460165438"
    }
  },
  {
    "like" : {
      "tweetId" : "1704128329732047146",
      "fullText" : "Have you ever worked with microdata from CBS (Statistics Netherlands) or from the LISS panel (or a combination of the two!) and have you made your code available? Please send it to me! Why? 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1704128329732047146"
    }
  },
  {
    "like" : {
      "tweetId" : "1704128336119857353",
      "fullText" : "Do you want to start sharing your code and don't know where to start? Check out this short guide by @ODISSEI_SoDa https://t.co/LqMLJ28Zw5 or get in touch!",
      "expandedUrl" : "https://twitter.com/i/web/status/1704128336119857353"
    }
  },
  {
    "like" : {
      "tweetId" : "1702347837076340765",
      "fullText" : "This looks like a fantastic opportunity! https://t.co/zYqbYotBo8",
      "expandedUrl" : "https://twitter.com/i/web/status/1702347837076340765"
    }
  },
  {
    "like" : {
      "tweetId" : "1575840077963751424",
      "fullText" : "📢 We have a shiny new website! 📢\n\nhttps://t.co/7I5piCUnDC\n\n✅Want to get in contact us? \n✅Find out how we work? \n✅See what kind of projects we do / have done? \n✅See who we are? \n✅Learn about scientific data analysis?\n\nGo to our new website👍 https://t.co/YBGIHvDLb1",
      "expandedUrl" : "https://twitter.com/i/web/status/1575840077963751424"
    }
  },
  {
    "like" : {
      "tweetId" : "1569232271852322819",
      "fullText" : "All the code 💻 is publicly available here: https://t.co/YwkjhFp57O",
      "expandedUrl" : "https://twitter.com/i/web/status/1569232271852322819"
    }
  },
  {
    "like" : {
      "tweetId" : "1518934469394186240",
      "fullText" : "In other words: this workshop is the best time investment you can imagine😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1518934469394186240"
    }
  },
  {
    "like" : {
      "tweetId" : "1483740347985444864",
      "fullText" : "Tomorrow the next Data Drop-in is scheduled where our @SoDa_nl team is ready to help you find an answer to all your social data related research questions. \n\nAll are welcome to zoom in between 16 and 17 hours! https://t.co/ADcQdLic7b",
      "expandedUrl" : "https://twitter.com/i/web/status/1483740347985444864"
    }
  },
  {
    "like" : {
      "tweetId" : "1470495475048534028",
      "fullText" : "1/ We host @SoDa_nl, the social data science team of our national digital infrastructure for the social &amp; behavioral sciences, @ODISSEI_nl. Cool projects from all over NL!",
      "expandedUrl" : "https://twitter.com/i/web/status/1470495475048534028"
    }
  },
  {
    "like" : {
      "tweetId" : "1468854340488212483",
      "fullText" : "Are you struggling with your data, programming or statistical methods? We (@SoDa_nl) can help you in our monthly SoDa drop-in. The next one is on Dec. 16th 4-5pm: https://t.co/bxhx9T0wm9",
      "expandedUrl" : "https://twitter.com/i/web/status/1468854340488212483"
    }
  },
  {
    "like" : {
      "tweetId" : "1461344994376126482",
      "fullText" : "Very interesting session on Open Science with Secure Data, linking to different parts of @ODISSEI_nl #ODISSEI2021. Many thanks @MelImming , @ejvankesteren (@SoDa_nl) and @BasvdKlaauw https://t.co/7S4cOw9nbB",
      "expandedUrl" : "https://twitter.com/i/web/status/1461344994376126482"
    }
  },
  {
    "like" : {
      "tweetId" : "1461331839025623045",
      "fullText" : "On behalf of Helen Lam and himself, @ejvankesteren of the @SoDa_nl team presents 'The great workaround: an Open Processing and Analysis Pipeline for Closed Data' #ODISSEI2021 https://t.co/0pafIOlyMx",
      "expandedUrl" : "https://twitter.com/i/web/status/1461331839025623045"
    }
  },
  {
    "like" : {
      "tweetId" : "1461037552232710154",
      "fullText" : "Give @SoDa_nl a follow for all your computational social science and open science questions. https://t.co/HVSgqkEhke",
      "expandedUrl" : "https://twitter.com/i/web/status/1461037552232710154"
    }
  }
]