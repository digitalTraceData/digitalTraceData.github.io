window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1447908998859079690",
      "emailChange" : {
        "changedAt" : "2021-10-13T08:02:00.000Z",
        "changedFrom" : "j.garciabernardo@uu.nl",
        "changedTo" : "soda@odissei-data.nl"
      }
    }
  }
]