window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Detuity",
                "screenName" : "@Detuity_com"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "skills"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "break"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-11-12 11:29:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1715008063709614473",
                "tweetText" : "Fraud attacks can devastate an ecommerce business — but one change can prevent that\n\nPartner Content with @Riskified",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TechCrunch"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722252151924425188",
                "tweetText" : "We generen ons een beetje om toe te geven dat we ons deze geniale verborgen bijzonderheden nu pas realiseren.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HomeTalk",
                "screenName" : "@HomeTalk_DIY"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721576492428382284",
                "tweetText" : "Through hard work and dedication, our employees have come to embody excellence. In that spirit, we continue to innovate and reliably deliver energy to the world \n\n#ExcellenceAwards\n#aramco90th\n#aramco https://t.co/ZAk6Vx8Qji",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/ZAk6Vx8Qji"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1719670643409490029",
                "tweetText" : "Start je reis goed en geniet van de luxe van het vliegen in Business Class bij KLM!\n\nBekijk de actuele aanbiedingen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DutchFlyGuys",
                "screenName" : "@DutchFlyGuys"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874483925484012",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 09:12:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1653800376414482450",
                "tweetText" : "Prijzen worden hoger, inkomsten worden lager en banen gaan verloren. \n\nAl met al grote economische gevolgen voor de gewone Nederlander.   \n\nWil jij deze lasten dragen van een loze klimaat oplossing?  \n\n#SaveSchiphol #SayNoTo400 https://t.co/ErdtmkhjTU",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/ErdtmkhjTU"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Red Schiphol",
                "screenName" : "@SaveSchiphol"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MinPres"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722205154341171257",
                "tweetText" : "Het voelt altijd alsof er meer te leren valt over reizen, en met deze eenvoudige tips kunnen we eindelijk een van die mensen zijn die er helemaal uitgerust uitzien na een vlucht.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Travlerz",
                "screenName" : "@Travlerz2"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 09:00:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874483925484012",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 08:59:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722954069017247985",
                "tweetText" : "Black Friday bij Auping! Nu 20% voordeel op bijna ons hele assortiment 🔥 Wees er snel bij, want de actie is maar kort geldig!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "98798",
                "name" : "#AupingNL20231113",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Auping",
                "screenName" : "@AupingNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 08:45:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Ribavo",
                "screenName" : "@Ribavocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "organize"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "study"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-13 08:45:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1723853180738666538",
                "tweetText" : "Why this head of sustainability can’t wait to make her job obsolete\n\nClick the image to read the full article\n\nPartner Content by Asahi Group Holdings",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Forbes"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1726189625167757805",
                "tweetText" : "Tijdens de #verkiezingen in Nederland moet u kiezen, maar bij ons mag u voor beide opties gaan! \n\nOntdek onze twee top-beleggingsfondsen en vink ze beiden aan voor uw financiële groei. Waarom kiezen als u ze beide kunt hebben? #beleggen #financiëletoekomst https://t.co/91dUrjWxFo",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/91dUrjWxFo"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Gini Capital",
                "screenName" : "@GiniCapitalNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1680020959179440128",
                "tweetText" : "Configure and automate your product's hosting infrastructure just how you like it. With Equinix Metal, #baremetal is the bare minimum.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Equinix Metal",
                "screenName" : "@equinixmetal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@GoogleCloudTech"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:43:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721900810190417992",
                "tweetText" : "Stream, creëer en ga de strijd aan op het hoogste niveau, met toonaangevende features en de nieuwste hybride architectuur. Configureer een 13e Generatie Intel® Core™ laptop bij PCSpecialist ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "PCSpecialist",
                "screenName" : "@PCSpecialist"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:46:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721673351259664837",
                "tweetText" : "Check out @danielmarbach's presentation of NServiceBus AWS Lambda and DynamoDB integration using SQS as a message transport.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Particular Software",
                "screenName" : "@ParticularSW"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@awscloud"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1723658028098990539",
                "tweetText" : "Register now for our Global IIoT Summit, which brings together global stakeholders and investors paving the way for IIoT innovations across sectors\n\nNovember 20-21, 2023\n\nhttps://t.co/cWM0V0W0Es\n\n#GIITS\n#aramco https://t.co/qhqo3d2jxw",
                "urls" : [
                  "https://t.co/cWM0V0W0Es"
                ],
                "mediaUrls" : [
                  "https://t.co/qhqo3d2jxw"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1725105269250666632",
                "tweetText" : "Probeer nu de gratis TVgids app. Minder zoeken, meer zien!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TVgids.nl",
                "screenName" : "@TVgidsnl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676128429150698",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:42:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Jean-Paul Fonteijn",
                "screenName" : "@JPFonteijn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:44:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1719987130376823020",
                "tweetText" : "Love this T-shirt!\nOrder here: https://t.co/fI8up9cPva https://t.co/2pLNNvGiNw",
                "urls" : [
                  "https://t.co/fI8up9cPva"
                ],
                "mediaUrls" : [
                  "https://t.co/2pLNNvGiNw"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "May The 4th Tee",
                "screenName" : "@maythe_4thtee"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@starwars"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-23 08:43:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1682005685733584897",
                "tweetText" : "I paid for this spot so you can enjoy this cute crab instead of seeing a boring ad. If you engage, this ad can keep running—just saying.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Jimmy Joy",
                "screenName" : "@jimmyjoyfood"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-23 08:47:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1723974226804150543",
                "tweetText" : "Black Friday bij Auping! Nu 20% voordeel op bijna ons hele assortiment 🔥",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Auping",
                "screenName" : "@AupingNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-23 08:42:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722162044923679024",
                "tweetText" : "Na jarenlange strijd verdwijnt een topstuk uit het Stedelijk Museum. Want: nazi-roofkunst. Maar is dat wel zo? Een podcast over historische schuld, Wassily Kandinsky en een schilderij van 60 miljoen euro.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-23 08:41:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-11-23 18:19:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-11-25 21:20:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1725547080653865256",
                "tweetText" : "Besparen op Black Friday is nog maar het begin van nog meer besparen. Direct. En voor altijd. Slim verwarmen met tado°. Bekijk de deals nu!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "tado°",
                "screenName" : "@tado"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-26 16:41:21"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722561518426816634",
                "tweetText" : "Bespaar nu echt geld! 😍\n\nOntdek al onze Black Friday aanbiedingen op onze website en in onze winkels!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Smyths Toys Superstores - NL",
                "screenName" : "@smythstoys_nl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Marvel"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LEGO_Group"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@starwars"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1728409316799951194",
                "tweetText" : "Get ready for an adventure with friends or followers! \n\nDive into a galaxy of over 40,000 voice transformations! 🚀🎤",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Davilico26",
                "screenName" : "@davilico26"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-11-27 21:36:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1714451252892090849",
                "tweetText" : "Love this T-shirt!\nOrder here: https://t.co/JuzmljejzM https://t.co/FudBEKUBfS",
                "urls" : [
                  "https://t.co/JuzmljejzM"
                ],
                "mediaUrls" : [
                  "https://t.co/FudBEKUBfS"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "May The 4th Tee",
                "screenName" : "@maythe_4thtee"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@starwars"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-27 21:38:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1699380925392380239",
                "tweetText" : "The MLOps stack component for experiment tracking\n\n🔹 Automate and standardize tracking as your modeling team grows\n\n🔹 Collaborate on models and results with your team and across the org\n\n🔹Integrate with any MLOps stack\n\nLearn more ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "neptune.ai",
                "screenName" : "@neptune_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AndrewYNg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kdnuggets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@drfeifei"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@KirkDBorne"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ylecun"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "app users - URL manual"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "App URL"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-27 21:38:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Vextoity",
                "screenName" : "@Vextoity"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "release"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "hand"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modeling"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1724577956419584130",
                "tweetText" : "#Ad Samsung Innovation Campus is dedicated to enabling young minds with the knowledge and skills needed to thrive in a rapidly evolving world. Explore how a combination of tech education and industry participation helps shape youths for the future.\nProduced with @Samsung",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Economist Impact",
                "screenName" : "@economistimpact"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722162044923679024",
                "tweetText" : "Na jarenlange strijd verdwijnt een topstuk uit het Stedelijk Museum. Want: nazi-roofkunst. Maar is dat wel zo? Een podcast over historische schuld, Wassily Kandinsky en een schilderij van 60 miljoen euro.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726465394519499216",
                "tweetText" : "Exposome is a fully open access, peer reviewed journal looking for new work that extends our understanding of the human exposome. Interested in contributing to cutting edge research in a new field? Discover why Exposome is the right home for your work:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Oxford Journals",
                "screenName" : "@OxfordJournals"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@openscience"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-27 21:37:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-30 08:25:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1729813453001646526",
                "tweetText" : "Wilders speelt met de optie het premierschap aan een ander („Omtzigt?”) te laten. „Dit zou de slechtst denkbare uitkomst zijn”, schrijft NRC-redacteur Tom-Jan Meeus.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-01 12:34:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1728476894058668157",
                "tweetText" : "Kadaster: woning met hoog energielabel verkoopt beter https://t.co/27k8r2lsCf. Wel jammer dan dat het Nederlandse energielabel goed fout zit. Een woning met Label A kan zomaar veel meer gas verbruiken dan dezelfde woning met Label C: https://t.co/rq3frZPAvT",
                "urls" : [
                  "https://t.co/27k8r2lsCf",
                  "https://t.co/rq3frZPAvT"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TONZON",
                "screenName" : "@Tonzon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "50 and up"
                }
              ],
              "impressionTime" : "2023-12-01 12:29:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722907084394479728",
                "tweetText" : "The facts about carbon capture and storage: how can it help return the world to sustainability?\n\nClick the image to read the full article\n\nPartner Content by @Equinor",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-05 12:21:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731641246781997058",
                "tweetText" : "Beleef de totale casino-ervaring zelf. Exclusieve spellen, eersteklas klantenservice &amp; dagelijkse gratis spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Online gaming"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2023-12-05 12:21:33"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730928092535836938",
                "tweetText" : "📍What is @COP28_UAE? Why is COP28 UAE important for 🇺🇦? Learn more here 👇\n\n#COP28 #COP28UAE  #COP28Ukraine #COP28DTEK https://t.co/W606KP5fdh",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/W606KP5fdh"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DTEK Group",
                "screenName" : "@dtek_en"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EUCouncil"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@IMFNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EU_Commission"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Europarl_EN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@eu_eeas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EUCouncilPress"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WorldBank"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Amsterdam"
                }
              ],
              "impressionTime" : "2023-12-06 09:11:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-12-06 12:11:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722285913634488776",
                "tweetText" : "We generen ons een beetje om toe te geven dat we ons deze geniale verborgen bijzonderheden nu pas realiseren.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HomeTalk",
                "screenName" : "@HomeTalk_DIY"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-06 12:11:48"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730538468500009289",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-07 15:54:08"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874483925484012",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-14 11:17:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Kevaby",
                "screenName" : "@KevabyCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "multiple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "unique"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "power"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "strong"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "bar"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "operation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "training"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-11-14 11:18:08"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Vozaware",
                "screenName" : "@Vozaware"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cleaning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "and more"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "behavior"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "growth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modern"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "left"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "door"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "change"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "job"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-08 14:24:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Huravo",
                "screenName" : "@Huravocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "calls"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "effective"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "impressive"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "parties"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "change"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "truck"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "provide"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-08 14:20:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Latixi",
                "screenName" : "@LatixiCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "effective"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "target"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "model"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "snowy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "travel"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "sign"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "aircraft"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "closed"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modern"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-08 14:24:23"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732039370146992313",
                "tweetText" : "Johan Remkes heeft de verkiezingsuitslag niet met grote vreugde waargenomen. „Tegelijkertijd dacht ik: dit overleven we ook wel weer.” De ex-informateur over de weerbaarheid van de democratie en de rol van het parlement.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-09 15:05:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Vozaware",
                "screenName" : "@Vozaware"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "birthday"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "design"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "intelligence"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "change"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "walk"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "view"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "explore"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "mind"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "hard"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-09 15:04:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1733121425823683006",
                "tweetText" : "Wil jij vanuit de expertise van bouw- en infrabedrijven werken aan de energietransitie? 🔥 Als adviseur in de vakgroep Ondergrondse Netwerken en Grondwaterbeheer verbind je leden &amp; breng je hun belangen over het voetlicht bij overheden, opdrachtgevers en samenwerkingspartners. 👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Bouwend Nederland",
                "screenName" : "@BouwendNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "North Brabant"
                }
              ],
              "impressionTime" : "2023-12-11 11:10:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 11:04:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732702382092353868",
                "tweetText" : "❌The Commission's broken promises mean broken lives for animals in cruel cages. Every minute counts. We refuse to stand by silently.\n\nJoin us in demanding new laws banning cages across the EU: https://t.co/lsSCJSDUp8  #EndTheCageAge #WeWant4Animals https://t.co/V4pzoiOOQw",
                "urls" : [
                  "https://t.co/lsSCJSDUp8"
                ],
                "mediaUrls" : [
                  "https://t.co/V4pzoiOOQw"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Compassion in World Farming International",
                "screenName" : "@CIWF_Global"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 11:10:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Lazzaco",
                "screenName" : "@Lazza_Homelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-11 11:13:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1699381428721533196",
                "tweetText" : "The MLOps stack component for experiment tracking\n\n🔹 Automate and standardize tracking as your modeling team grows\n\n🔹 Collaborate on models and results with your team and across the org\n\n🔹Integrate with any MLOps stack\n\nLearn more ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "neptune.ai",
                "screenName" : "@neptune_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AndrewYNg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kdnuggets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@drfeifei"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@KirkDBorne"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ylecun"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "app users - URL manual"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "App URL"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                }
              ],
              "impressionTime" : "2023-12-11 11:04:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730538468500009289",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-11 11:10:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722182025870782766",
                "tweetText" : "Stream, creëer en ga de strijd aan op het hoogste niveau, met toonaangevende features en de nieuwste hybride architectuur. Configureer een 13e Generatie Intel® Core™ laptop bij PCSpecialist ➡️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "PCSpecialist",
                "screenName" : "@PCSpecialist"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 11:10:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732038363761303658",
                "tweetText" : "Zo onversneden conservatief als Wilders is over immigratie en de islam, zo klassiek links zou de PVV zijn als het gaat om economische thema’s. Maar klopt dat eigenlijk wel?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-12-11 11:05:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730538468470620185",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 08:33:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1699380925392380239",
                "tweetText" : "The MLOps stack component for experiment tracking\n\n🔹 Automate and standardize tracking as your modeling team grows\n\n🔹 Collaborate on models and results with your team and across the org\n\n🔹Integrate with any MLOps stack\n\nLearn more ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "neptune.ai",
                "screenName" : "@neptune_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AndrewYNg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kdnuggets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@drfeifei"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@KirkDBorne"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ylecun"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "app users - URL manual"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "App URL"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1724396113564668398",
                "tweetText" : "View the programme for the speakers &amp; talks at our 2024 Journal Meeting 'Diversity and Evolution in Cell Biology' organised by Gautam Dey, Lillian Fritz-Laylin, Snezhka Oliferenko, Meg Titus &amp; Michael Way\n\nhttps://t.co/ofpFt3WkBd\n#JCSevocellbio",
                "urls" : [
                  "https://t.co/ofpFt3WkBd"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "J Cell Science",
                "screenName" : "@J_Cell_Sci"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PLOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731638730119622842",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app. Wat kost gokken jou? Stop op tijd. 18+",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730613879577665794",
                "tweetText" : "Deze ontwerpen herinneren ons dat omdat we het kunnen, we het nog niet hoeven te doen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HomeTalk",
                "screenName" : "@HomeTalk_DIY"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-12-11 09:29:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721838814841213196",
                "tweetText" : "Free Press Unlimited steunt journalisten, in Nederland en wereldwijd.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Free Press Unlimited",
                "screenName" : "@freepressunltd"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 09:09:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727578476121870576",
                "tweetText" : "De stemmen zijn geteld. Een nieuw tijdperk begint. \nWat komt er terecht van alle verkiezingsbeloftes? \n\nHet nieuws, de analyses en de onderzoeksjournalistiek van NRC geven je grip op de wereld.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 09:23:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 09:24:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730615001554002358",
                "tweetText" : "Deze ontwerpen herinneren ons dat omdat we het kunnen, we het nog niet hoeven te doen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HomeTalk",
                "screenName" : "@HomeTalk_DIY"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730567691432325338",
                "tweetText" : "Influencers overtuigden ons van deze reisbestemmingen, maar toen we zagen hoe ze in werkelijkheid zijn, moesten we gewoon lachen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TheFunPost",
                "screenName" : "@TheFunPost1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722162044923679024",
                "tweetText" : "Na jarenlange strijd verdwijnt een topstuk uit het Stedelijk Museum. Want: nazi-roofkunst. Maar is dat wel zo? Een podcast over historische schuld, Wassily Kandinsky en een schilderij van 60 miljoen euro.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-12-11 09:09:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721673351259664837",
                "tweetText" : "Check out @danielmarbach's presentation of NServiceBus AWS Lambda and DynamoDB integration using SQS as a message transport.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Particular Software",
                "screenName" : "@ParticularSW"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@awscloud"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 09:23:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732784858840158502",
                "tweetText" : "Saudi Arabia is building a blueprint for the future of aviation\n\nClick the image to read the full article\n\nPartner Content by PIF",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FortuneMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Telegraph"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@guardian"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Independent"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuffPost"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCBreaking"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730653756432253044",
                "tweetText" : "Deze ontwerpen herinneren ons dat omdat we het kunnen, we het niet per sé hoeven te doen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kueez",
                "screenName" : "@Kueez1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 09:10:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732784858701730294",
                "tweetText" : "Saudi Arabia is set to provide us with a blueprint for renewable energy systems\n\nClick the image to read the full article\n\nPartner Content by PIF",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FortuneMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Telegraph"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@guardian"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Independent"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuffPost"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCBreaking"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "dominicmc.eth",
                "screenName" : "@Achllios"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Lorenzo Righi",
                "screenName" : "@LorenzoRighi4"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1733416600924016993",
                "tweetText" : "OPEC is pushing against #fossilfuel #phaseout at #COP28\nAsking these countries to lobby against it 👇 https://t.co/y92GiiZMcI",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/y92GiiZMcI"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UNCS News",
                "screenName" : "@UNClimateSummit"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 13:41:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729813452850397436",
                "tweetText" : "„Het totale onvermogen om aan besturen toe te komen, heeft kiezers bij de traditionele partijen weggejaagd”, zegt politicoloog Catherine Fieschi. Recht in de armen van extreemrechtse partijen. Die zijn steeds beter geworden in de macht behouden, blijkt in de rest van Europa.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730650985788313868",
                "tweetText" : "Deze ontwerpen herinneren ons dat omdat we het kunnen, we het nog niet hoeven te doen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kueez",
                "screenName" : "@Kueez1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 13:47:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Latixi",
                "screenName" : "@LatixiCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fast"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "classic"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "simple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "rest"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "daily"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modern"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 13:47:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729813453001646526",
                "tweetText" : "Wilders speelt met de optie het premierschap aan een ander („Omtzigt?”) te laten. „Dit zou de slechtst denkbare uitkomst zijn”, schrijft NRC-redacteur Tom-Jan Meeus.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 13:38:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1652810058147954689",
                "tweetText" : "You could publish your next article open access at no cost thanks to the VSNU open access agreement with Taylor &amp; Francis.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor & Francis Research Insights",
                "screenName" : "@tandfonline"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UniUtrecht"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1724973423217217708",
                "tweetText" : "Explore Vercel’s interoperable, streaming-enabled, edge-ready software dev kit for AI apps.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Vercel",
                "screenName" : "@vercel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@getbootstrap"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 13:21:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734122501087908161",
                "tweetText" : "RT @WeDontHaveTime: 🟢 LIVE: Join us on the final day 11 of the #COP28 Climate Hub! 💚\nWatch the last of our daily broadcasts from the heart…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Exponential Roadmap Initiative",
                "screenName" : "@exponentialroad"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNEP"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EU_Commission"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coe"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNFCCC"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNICEF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNDP"
                }
              ],
              "impressionTime" : "2023-12-11 13:38:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1717616625094967733",
                "tweetText" : "The future doesn’t have to be a great unknown.\n\nChainlink is your gateway to onchain finance.\n\nThe future is on.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Chainlink",
                "screenName" : "@chainlink"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FortuneMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HarvardBiz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Forbes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@markets"
                }
              ],
              "impressionTime" : "2023-12-11 10:54:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1731373640862798100",
                "tweetText" : "🚀 Enter the RoostGPT Era: Effortless Testing! Imagine seamless software testing with our Large Langue Models (LLMs) and Generative AI. RoostGPT automates test cases, freeing you to innovate and enjoy. #LLM #ChatGPT",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roost.ai",
                "screenName" : "@Roost"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-12-11 10:42:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731629423453950224",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2023-12-11 10:42:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Bevereo",
                "screenName" : "@Bevereocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "effects"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "led"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "unique"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-11 10:42:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734148517764149571",
                "tweetText" : "Er spelen veel complexe thema’s. Van wonen en klimaat tot migratie en landbouw. Ga goed geïnformeerd de feestdagen in met een NRC-abonnement, nu vanaf €2,- per week.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 10:24:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732752317919686984",
                "tweetText" : "Energy policy making is complicated. Take our quiz to better understand what's at stake\n\nClick the image to take our quiz\n\nPartner Content by @Equinor",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-11 10:53:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732428448965014013",
                "tweetText" : "Deze vindingrijke personen hadden geen ingenieursdiploma nodig.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TheFunPost",
                "screenName" : "@TheFunPost1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 10:54:04"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1691751098087051478",
                "tweetText" : "Love this T-shirt!\nOrder here: https://t.co/lAMQSsEQQe https://t.co/LAsVyhhmEo",
                "urls" : [
                  "https://t.co/lAMQSsEQQe"
                ],
                "mediaUrls" : [
                  "https://t.co/LAsVyhhmEo"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "May The 4th Tee",
                "screenName" : "@maythe_4thtee"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@starwars"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 15:55:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "keiwalker.eth",
                "screenName" : "@jhvfjfghciykytf"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 15:55:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732784859683176577",
                "tweetText" : "Saudi Arabia's city within an airport is set to revolutionise air travel\n\nClick the image to read the full article\n\nPartner Content by PIF",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FortuneMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Telegraph"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@guardian"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Independent"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuffPost"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCBreaking"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-11 15:55:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734243269943386191",
                "tweetText" : "Ben jij erbij op 17 december? ✨ Ervaar marathonschaatsen van dichtbij tijdens de Staatsloterij Schaatsmarathon op de Jaap Eden IJsbaan in Amsterdam! #Schaatsmarathon\n\nKoop nu je tickets via https://t.co/YYhaCLtb2d",
                "urls" : [
                  "https://t.co/YYhaCLtb2d"
                ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "99318",
                "name" : "#schaatsennl20231211",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "schaatsen.nl",
                "screenName" : "@schaatsennl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-11 18:31:43"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1730653756432253044",
                "tweetText" : "Deze ontwerpen herinneren ons dat omdat we het kunnen, we het niet per sé hoeven te doen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kueez",
                "screenName" : "@Kueez1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-12 11:45:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Bozyno",
                "screenName" : "@BozynoCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "relief"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "power"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "details"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "camera"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-12 12:07:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732038363761303658",
                "tweetText" : "Zo onversneden conservatief als Wilders is over immigratie en de islam, zo klassiek links zou de PVV zijn als het gaat om economische thema’s. Maar klopt dat eigenlijk wel?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-12 12:08:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1677086759417511936",
                "tweetText" : "Collaborating to create new value from ocean plastic waste.\n\n@Microsoft\n#SABIC https://t.co/lvSybTJKqW",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/lvSybTJKqW"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SABIC I سابك",
                "screenName" : "@SABIC"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Microsoft"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wef"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Apple"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-12 12:08:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732428448965014013",
                "tweetText" : "Deze vindingrijke personen hadden geen ingenieursdiploma nodig.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TheFunPost",
                "screenName" : "@TheFunPost1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-12 12:07:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1720353058935205989",
                "tweetText" : "🚆🏔️Vind de goedkoopste treinkaartjes naar de mooiste Europese bestemmingen.\n\nVergelijk tickets, stedentrips en rondreizen. Alles op 1 plek!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "locomocheap",
                "screenName" : "@locomocheap"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-12-12 21:20:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721838814841213196",
                "tweetText" : "Free Press Unlimited steunt journalisten, in Nederland en wereldwijd.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Free Press Unlimited",
                "screenName" : "@freepressunltd"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-12 21:20:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734501717398475184",
                "tweetText" : "New boxes from Trust Wallet. There's a 48H⌚",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Tawnya Harries",
                "screenName" : "@HarriesTaw18339"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-12 21:20:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734148517764149571",
                "tweetText" : "Er spelen veel complexe thema’s. Van wonen en klimaat tot migratie en landbouw. Ga goed geïnformeerd de feestdagen in met een NRC-abonnement, nu vanaf €2,- per week.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NRC",
                "screenName" : "@nrc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-12 18:38:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Blevex",
                "screenName" : "@BlevexCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "win"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "powerful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "field"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "reading"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "deal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "flying"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "gap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "style"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-13 13:06:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734243269943386191",
                "tweetText" : "Ben jij erbij op 17 december? ✨ Ervaar marathonschaatsen van dichtbij tijdens de Staatsloterij Schaatsmarathon op de Jaap Eden IJsbaan in Amsterdam! #Schaatsmarathon\n\nKoop nu je tickets via https://t.co/YYhaCLtb2d",
                "urls" : [
                  "https://t.co/YYhaCLtb2d"
                ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "99346",
                "name" : "#schaatsennl20231213",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "schaatsen.nl",
                "screenName" : "@schaatsennl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-13 13:05:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Latugo",
                "screenName" : "@Latugocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "study"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "material"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "deep"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nice"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "van"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "real"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "package"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "win"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-13 13:06:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731638730119622842",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app. Wat kost gokken jou? Stop op tijd. 18+",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-12-13 13:06:31"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Kosuva",
                "screenName" : "@KosuvaCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "sign"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "twitter"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "read"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "public"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "january"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "summer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "school"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "book"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "details"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learn"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "type"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "food"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "party"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "international"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 10:59:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Hogh-hotel",
                "screenName" : "@hoghhotel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:29:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1735310313141002558",
                "tweetText" : "$1 MILLION. 1 WINNER. \n\n 7 Days left to Enter. \n\nWill you be THE Meta Winner? \n\nFree Entry: https://t.co/ib5OFP99D0",
                "urls" : [
                  "https://t.co/ib5OFP99D0"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "METAWIN",
                "screenName" : "@Meta_Winners"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:22:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734586161492865361",
                "tweetText" : "Pitingo lo tiene muy claro. Tod@s estamos en esto junt@s, hay que reciclar vidrio y cuidar del planeta ♻️ https://t.co/8QxJy7rA0V",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/8QxJy7rA0V"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ecovidrio 🌍",
                "screenName" : "@ecovidrio"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:00:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Flower Patch",
                "screenName" : "@Flower_Patch_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:52:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1735308190105973133",
                "tweetText" : "Las noticias de la semana conmocionan con sus historias",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Tripp Lewis",
                "screenName" : "@TrippLewis405"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:02:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Floral Memories",
                "screenName" : "@floralmemoriesb"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:01:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Bozely",
                "screenName" : "@Bozelyshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learn"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "sign"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "summer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "party"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "food"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "celebrate"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:00:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Herpato",
                "screenName" : "@HerpatoCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ja"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "twitter"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "earth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "public"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "incredible"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "details"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "-"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "highly"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:00:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1735322230337220710",
                "tweetText" : "Tendrá que pedir perdón por esta falta durante mucho tiempo, pero aún está pendiente de juicio por este caso",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Vander Ramirez",
                "screenName" : "@VanderRami87985"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:52:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734602866386444345",
                "tweetText" : "https://t.co/LyeIrOM7eX",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/LyeIrOM7eX"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Opera",
                "screenName" : "@opera"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@googlechrome"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@firefox"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:52:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729042864250687574",
                "tweetText" : "Y un año más, la magia de la Navidad llega de la mano de Lidl 🦝❤️\n\n#LaMagiaDeLaNavidadConLidl ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lidl España",
                "screenName" : "@lidlespana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-15 11:52:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1735566725343768764",
                "tweetText" : "El mensaje de Lola Índigo al gobierno",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wyndhmhotel",
                "screenName" : "@wyndhmhotel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:28:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1735397497739399650",
                "tweetText" : "Cambiar la caldera de gas por #aerotermia + #panelessolares☀️. \n\nEso hizo esta guardería de #Guadalajara, que se calienta (y se refresca) a través del suelo y tienen la piscina climatizada. \n\nEn 5 meses han ahorrado 2.500€, no contaminan y disfrutan de un confort ¡incomparable! https://t.co/y4uQv5BuGz",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/y4uQv5BuGz"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Iberdrola",
                "screenName" : "@iberdrola"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:53:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734963652044751102",
                "tweetText" : "thats why you are still in the hood https://t.co/R4PJjfRkvu",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/R4PJjfRkvu"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Opera",
                "screenName" : "@opera"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@googlechrome"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@firefox"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-15 11:22:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732053874004181387",
                "tweetText" : "RT @Educaixa: Alfons Cornella, co-creador de Jóvenes Emprendedores, el programa que fue el germen de #TheChallengebyEduCaixa, nos explica c…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fundación ”la Caixa”",
                "screenName" : "@FundlaCaixa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:53:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734168562418225662",
                "tweetText" : "¡Ponemos a prueba a Chat GPT! ¿Cuánto sabrá sobre nuestros pilotos? \n\n#EquipoRepsolHonda \n#MM93 \n#JM36\n#MotoGP\n#Motociclismo https://t.co/QyUewwrGsG",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/QyUewwrGsG"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Box_Repsol",
                "screenName" : "@box_repsol"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-15 11:53:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Margaret",
                "screenName" : "@Jovialhgg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-15 11:29:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734235228183449910",
                "tweetText" : "😍🔨There's never any need to swing a sharp, heavy axe, the cast iron splitting head remains stationary, permanently mounted inside a cast metal frame.\n👉 https://t.co/BxuudRBgOU https://t.co/ITAQyY7b2H",
                "urls" : [
                  "https://t.co/BxuudRBgOU"
                ],
                "mediaUrls" : [
                  "https://t.co/ITAQyY7b2H"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kevizo",
                "screenName" : "@Kevizocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "partner"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "12"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "kinetic"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-15 11:21:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Billizo",
                "screenName" : "@Billizocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "read"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "christmas"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "statement"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "sound"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "energy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cool"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-12-15 16:51:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734264532493877475",
                "tweetText" : "La espera es algo que se disfruta si merece la pena. \n\nAunque sean 10 años. \n\nBallantine's 10. Perdón por la espera.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ballantine's España",
                "screenName" : "@Ballantines_ES"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "50 and up"
                }
              ],
              "impressionTime" : "2023-12-15 14:53:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1697584085588430860",
                "tweetText" : "Si Quieres Saber Cómo Quitar la Silicona de Cualquier Superficie No te Puedes Perder esta Guía Práctica para Lograrlo ☝ en GENERALI #TuAsesorHogar",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "GENERALI España",
                "screenName" : "@GENERALI_es"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-12-15 14:53:18"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Hozzex",
                "screenName" : "@HozzexStore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "action"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "unique"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "education"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "model"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "2023"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "party"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "final"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-17 13:00:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731955813411930542",
                "tweetText" : "👓Reading glasses that can see far and near. 😲smart zoom! No matter how far or near.\n👉 https://t.co/0m6bQTlVNx https://t.co/PfMlOcWP6F",
                "urls" : [
                  "https://t.co/0m6bQTlVNx"
                ],
                "mediaUrls" : [
                  "https://t.co/PfMlOcWP6F"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kreypo",
                "screenName" : "@Kreyposhop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "school"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "13"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "media"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "party"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "25"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "person"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "honored"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "15"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "40"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "share"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "reading"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-17 13:00:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721400027677970578",
                "tweetText" : "🏘No need to punch holes, no damage to the wall. ⚡Easily organize your home wires, cables and data lines.🛠\n\nGet it now👉 https://t.co/AM9KotTVgA https://t.co/TNJoM9rxEn",
                "urls" : [
                  "https://t.co/AM9KotTVgA"
                ],
                "mediaUrls" : [
                  "https://t.co/TNJoM9rxEn"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Velyon",
                "screenName" : "@Velyonstore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "control"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "2023"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "head"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-14 15:38:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721399877769323000",
                "tweetText" : "🏘No need to punch holes, no damage to the wall. ⚡Easily organize your home wires, cables and data lines.🛠\n\nGet it now👉 https://t.co/AM9KotTVgA https://t.co/0XZcnf7LpO",
                "urls" : [
                  "https://t.co/AM9KotTVgA"
                ],
                "mediaUrls" : [
                  "https://t.co/0XZcnf7LpO"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Velyon",
                "screenName" : "@Velyonstore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "desks"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "2023"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-14 20:51:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1723181982991946139",
                "tweetText" : "For people who sit a lot, move little and are therefore inflexible and have pain.\n👉 https://t.co/NcsqxOANrJ https://t.co/KIz5iCUQPk",
                "urls" : [
                  "https://t.co/NcsqxOANrJ"
                ],
                "mediaUrls" : [
                  "https://t.co/KIz5iCUQPk"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sumoze",
                "screenName" : "@Sumozeshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "multiple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "performance"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blue"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-14 20:51:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1648703248012910592",
                "tweetText" : "This is a game I wanted to make my entire life! Can you guess games which have inspired me the most?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Settlings",
                "screenName" : "@TheSettlings"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-14 20:54:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726282676422811761",
                "tweetText" : "Just 5 minutes brought great relief to your neck! \n👉 https://t.co/BVXlSvDx0r https://t.co/DvCUToaimu",
                "urls" : [
                  "https://t.co/BVXlSvDx0r"
                ],
                "mediaUrls" : [
                  "https://t.co/DvCUToaimu"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kepavo",
                "screenName" : "@Kepavo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "kids"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "15"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "50"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "16"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "self-care"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "pain"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "relieve"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-18 09:24:48"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732779373663515107",
                "tweetText" : "🚨 Being in the project early IS what gets rewarded the most in web3!\n\nExample?\n\nThe project that’s backed by VC that has visionary early-invested in Tesla &amp; SpaceX:\n\n@DeFi might be keeping some surprises for its early adopters!\n\nFew weeks left! Start now! 👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "De.Fi 2.0",
                "screenName" : "@DeFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2023-12-19 08:19:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1650495651816394752",
                "tweetText" : "Do you need C++ TeX Manipulation Library? Aspose.TeX for C++ is a flexible and easy-to-use library to typeset TeX files. API supports multiple output formats like XPS, PDF, PNG, JPEG, TIFF, and BMP. Download a Free Trial!  #CPP #API #Programming",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StackOverflow"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-19 08:19:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1736783882920382742",
                "tweetText" : "$1 MILLION. 1 WINNER. \n\n3 Days left to Enter. \n\nWill you be THE Meta Winner? \n\nFree Entry: https://t.co/ib5OFP99D0",
                "urls" : [
                  "https://t.co/ib5OFP99D0"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "METAWIN",
                "screenName" : "@Meta_Winners"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-19 08:18:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729042864250687574",
                "tweetText" : "Y un año más, la magia de la Navidad llega de la mano de Lidl 🦝❤️\n\n#LaMagiaDeLaNavidadConLidl ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lidl España",
                "screenName" : "@lidlespana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-19 08:19:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1736395070897573927",
                "tweetText" : "¿Firmarías nuevas aventuras con estas Skechers #MAXCushioning? 😏 \n\n¡Únete a Skechers Plus y consigue 5€ de bienvenida! 😜 #CorriendoConSkechers \n\nhttps://t.co/Vd5XrLNrSf https://t.co/nSp7uReq5P",
                "urls" : [
                  "https://t.co/Vd5XrLNrSf"
                ],
                "mediaUrls" : [
                  "https://t.co/nSp7uReq5P"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Skechers Spain",
                "screenName" : "@SkechersSpain"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@amazon"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-12-19 08:19:17"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1720431236554838060",
                "tweetText" : "Endesa, Naturgy e Iberdrola no quieren que sepas que puedes producir tu propia energía. \n\nSi quieres saber cómo puedes hacerlo sean cuales sean tus circunstancias, descárgate gratis la guía de autoconsumo 👉 https://t.co/GT793tTVmT https://t.co/cCW7TfwGuy",
                "urls" : [
                  "https://t.co/GT793tTVmT"
                ],
                "mediaUrls" : [
                  "https://t.co/cCW7TfwGuy"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Greenpeace España",
                "screenName" : "@greenpeace_esp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NatGeo"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NatGeoTV"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@GretaThunberg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@IPCC_CH"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WWF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Greenpeace"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-20 12:07:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732806601743147116",
                "tweetText" : "RT @DeDotFiSecurity: Almost $1M trading volume in 24hrs\n\n-98% in just 3 hours.\n\nHere is an easy way to check tokens for red flags using htt…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "De.Fi 2.0",
                "screenName" : "@DeFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1737144005840781743",
                "tweetText" : "$1 MILLION. 1 WINNER. \n\n2 Days left to Enter. \n\nWill you be THE Meta Winner? \n\nFree Entry: https://t.co/ib5OFP99D0",
                "urls" : [
                  "https://t.co/ib5OFP99D0"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "METAWIN",
                "screenName" : "@Meta_Winners"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1737068781241761838",
                "tweetText" : "¡SORTEO! 👇\nSolo para los que han sido buenos 🤪\n\nGana un viaje en el 💫 Tren de la Navidad (https://t.co/9Wtevv23bP) para viajar del 26 de diciembre al 4 de enero (excepto los días 31 de diciembre y 1 de enero) para ti y tres acompañantes. Un Paje Real, muy majo, os recibirá en… https://t.co/yOUI5CEczP",
                "urls" : [
                  "https://t.co/9Wtevv23bP"
                ],
                "mediaUrls" : [
                  "https://t.co/yOUI5CEczP"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Renfe",
                "screenName" : "@Renfe"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Valladolid"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726597723321737672",
                "tweetText" : "New Web3 Vulnerabilities &amp; Frauds appear daily 👎\n\nHow can you be sure you have never interacted with them? \n🤷‍♂️ Exactly. You can't.\n\nIt took YEARS to build your net worth. Don't lose it in seconds!\n\n⚡️ Scan any Web3 Token or Smart Contract before interacting with it. \n\nIt's free.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "De.Fi 2.0",
                "screenName" : "@DeFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1735652412403114013",
                "tweetText" : "Hasta en el viaje más importante de la #Navidad, nunca merece la pena correr. Gracias por #ConducirConPrecaución y Felices Fiestas de parte de la Dirección General de Tráfico.\n\nDescubre más sobre el viaje de Papá Noel en https://t.co/BfTCXaTOfM\n#Llegar https://t.co/uRAA5wyTKi",
                "urls" : [
                  "https://t.co/BfTCXaTOfM"
                ],
                "mediaUrls" : [
                  "https://t.co/uRAA5wyTKi"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Dir. Gral. Tráfico",
                "screenName" : "@DGTes"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729042864250687574",
                "tweetText" : "Y un año más, la magia de la Navidad llega de la mano de Lidl 🦝❤️\n\n#LaMagiaDeLaNavidadConLidl ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lidl España",
                "screenName" : "@lidlespana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-12-20 08:21:37"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1733312165858156704",
                "tweetText" : "😍My boyfriend bought me this. Still in love with them.\n👉 https://t.co/13jtq4Fxxw https://t.co/A88P9qsmjy",
                "urls" : [
                  "https://t.co/13jtq4Fxxw"
                ],
                "mediaUrls" : [
                  "https://t.co/A88P9qsmjy"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Depenza",
                "screenName" : "@Depenzashop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "11"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "12"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "single"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "key"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fast"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "exchange"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "share"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "perfect"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "24"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "house"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "20"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "watch"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-20 16:25:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1729080845095379072",
                "tweetText" : "Las falsificaciones pueden darte sorpresas muy desagradables, no hay garantías del correcto funcionamiento de un producto falsificado.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "OEPM",
                "screenName" : "@OEPM_es"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-20 16:25:38"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Tonizy",
                "screenName" : "@Tonizyshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "15"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "simple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "city"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "hand"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "books"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "videos"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "tweet"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "40"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "taylor"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "list"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "university"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "based"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "door"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "12"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "students"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "17"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-22 11:23:53"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1737141456286921202",
                "tweetText" : "En 2013 algunos dudaban de los riesgos, hoy cientos de miles de personas sufren las consecuencias de no protegerse adecuadamente. \n\nEscucha lo que se decía entonces y actúa hoy, no permitas que tus ojos sigan sufriendo.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Reticare - Único científicamente probado",
                "screenName" : "@ReticareSpain"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WomensHealthMag"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-27 11:50:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1736236939903127957",
                "tweetText" : "How to Escape a Sinking Car In An Emergency (Do This Now)🚗⚠️ SafeHammer is a must-have safety device that could save your life! 💡 Trusted by thousands of emergency responders.\n👉 https://t.co/Y0zk3BjXUy https://t.co/BPU9blt8hG",
                "urls" : [
                  "https://t.co/Y0zk3BjXUy"
                ],
                "mediaUrls" : [
                  "https://t.co/BPU9blt8hG"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bozento",
                "screenName" : "@Bozentoshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "baby"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "100"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "christmas"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "engine"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "share"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "teaching"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-27 11:50:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1738209961170051319",
                "tweetText" : "These bands will remind you of a better time in life. How much do you remember?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bleacher Breaker",
                "screenName" : "@Bleacher__break"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-12-27 11:50:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1735652412403114013",
                "tweetText" : "Hasta en el viaje más importante de la #Navidad, nunca merece la pena correr. Gracias por #ConducirConPrecaución y Felices Fiestas de parte de la Dirección General de Tráfico.\n\nDescubre más sobre el viaje de Papá Noel en https://t.co/BfTCXaTOfM\n#Llegar https://t.co/uRAA5wyTKi",
                "urls" : [
                  "https://t.co/BfTCXaTOfM"
                ],
                "mediaUrls" : [
                  "https://t.co/uRAA5wyTKi"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Dir. Gral. Tráfico",
                "screenName" : "@DGTes"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-27 12:11:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731737299384139781",
                "tweetText" : "Lo bueno se hace esperar.\n\nComo la Navidad, que tarda todo el año en llegar. O como Ballantine's 10 que por fin está aquí.\n\n¡No esperes más para probarlo!\n\nhttps://t.co/x3ejbMfKDf https://t.co/SkGTJoYD6N",
                "urls" : [
                  "https://t.co/x3ejbMfKDf"
                ],
                "mediaUrls" : [
                  "https://t.co/SkGTJoYD6N"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ballantine's España",
                "screenName" : "@Ballantines_ES"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "50 and up"
                }
              ],
              "impressionTime" : "2023-12-27 12:12:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1737763583499334115",
                "tweetText" : "✨ Este Día de Reyes sorprende con regalos que encantan a precios increíbles 🎁 Solo en Carrefour, ¿te lo vas a perder?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Carrefour España",
                "screenName" : "@CarrefourES"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@amazon"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Home entertainment"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tablets"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-27 12:10:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1739322362820985255",
                "tweetText" : "🚨 The $100k Quest by @DeFi has JUST BEGUN!\n\nThe rules? Really simple!\n\nComplete daily tasks (such as quizzes, riddles, or swaps) &amp; win up to $100k! 🎁\n\nBut most importantly: the EARLIER to join the Quest, the more chances you get to WIN! #de_fi \n\nClock ticks! ⏰",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "De.Fi 2.0",
                "screenName" : "@DeFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2023-12-27 12:13:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1737044827357790683",
                "tweetText" : "¿Quieres optimizar el uso de tu lavadora? Aquí te contamos unos trucos para sacarle el mejor partido mientras ahorras🔄💰 https://t.co/US54u6FYlq",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/US54u6FYlq"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Iberdrola Clientes",
                "screenName" : "@TuIberdrola"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-27 12:13:40"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708742207815954909",
                "tweetText" : "You Are Probably Overpaying on Amazon! This is How to Stop.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Karma Shopping",
                "screenName" : "@karma_shopping"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "…"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "days"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "watch"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "rt"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "week"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Complete Registrations"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Subscribe"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-12-28 20:14:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1739914017445974384",
                "tweetText" : "Seal, waterproof, and stop leaks in a flash – just 10 seconds! 💦🚀\n👉 https://t.co/4rAHNuB5II https://t.co/iKxRL0OtGR",
                "urls" : [
                  "https://t.co/4rAHNuB5II"
                ],
                "mediaUrls" : [
                  "https://t.co/iKxRL0OtGR"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Filzime",
                "screenName" : "@Filzime"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "simple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "career"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "christmas"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "wonderful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 11:02:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1740721076064165926",
                "tweetText" : "Many failed before. Will YOU complete the trial?🧙‍♂️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hero Wars",
                "screenName" : "@HeroWarsWeb"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 11:27:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1736606826181890476",
                "tweetText" : "Sleep enhancing cervical support comfort goose down pillow.\n👉 https://t.co/0JlAE1elNx https://t.co/o5Tb4x4R8h",
                "urls" : [
                  "https://t.co/0JlAE1elNx"
                ],
                "mediaUrls" : [
                  "https://t.co/o5Tb4x4R8h"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Tuppoian",
                "screenName" : "@Tuppoian"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "11"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "real"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cool"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "12"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "14"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "christmas"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "media"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "20"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "boys"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "wonderful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "30"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "career"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "start"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 11:27:15"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1743378009082531840",
                "tweetText" : "Not at CES? We’ve got you covered with a backstage pass to the future of technology! \nX is your one stop shop for all things #CES2024: watch a live stream, catch up with daily recaps, and join the conversation.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Business",
                "screenName" : "@XBusiness"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "machine learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "grok"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 16:11:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1735223451558834388",
                "tweetText" : "😎💦 Waterproof, seal cracks, and achieve quick leak-proof results in just 10 seconds!\n👉 https://t.co/4rAHNuB5II https://t.co/8psbSauC9Z",
                "urls" : [
                  "https://t.co/4rAHNuB5II"
                ],
                "mediaUrls" : [
                  "https://t.co/8psbSauC9Z"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Filzime",
                "screenName" : "@Filzime"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "wonderful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "solutions"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "simple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "career"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "professional"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "share"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 14:59:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Teppeic",
                "screenName" : "@Teppeic_com"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "comments"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "hotel"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "reviews"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "city"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "days"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "book"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "view"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "real"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "future"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "university"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "add"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-08 14:59:52"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742582087557771488",
                "tweetText" : "♻️ El meteorólogo Martín Barreiro estuvo siguiendo el viaje de un envase de vidrio desde el contenedor verde hasta una planta de reciclaje. ¿Quieres ver cómo fue? 👀\n\n#VidrioTransparente #AlianzaConciencia https://t.co/z9syfTonEF",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/z9syfTonEF"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ecovidrio 🌍",
                "screenName" : "@ecovidrio"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Galicia"
                }
              ],
              "impressionTime" : "2024-01-09 14:46:10"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1704124966982021326",
                "tweetText" : "A new era in Data Science is here 🚀.\nSay hello to your Chief AI Chat Data Scientist!\nFrom this day forward, advanced analytics and automated data workflows are within anyone's reach. We like to call it \"Freedom To Create\".",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Carlos Mendez",
                "screenName" : "@charlesmendez"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-15 11:03:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1724048276834402478",
                "tweetText" : "De feestdagen staan we voor de deur. Maar heb jij al een kado? Ehhhh.. Geef een December Kalender! Hét kado voor de feestdagen. #DecemberKalender",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "98829",
                "name" : "#Kraslotennl20231115",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Krasloten",
                "screenName" : "@Kraslotennl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-15 11:03:32"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1650495651413729283",
                "tweetText" : "Do you need C++ TeX Manipulation Library? Try it for free!! \n\n#CPP #API #Programming\n\nhttps://t.co/kmEkWYaeI3",
                "urls" : [
                  "https://t.co/kmEkWYaeI3"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StackOverflow"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2024-01-10 09:51:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742481228949749795",
                "tweetText" : "¿Estás preparado para una nueva era del móvil? #GalaxyAI está al caer✨\n\nÚnete al #SamsungUnpacked el 17 de enero de 2024 a las 19h.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung España",
                "screenName" : "@SamsungEspana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-10 08:33:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1743223857442398216",
                "tweetText" : "SÓLO CON 1LIKE 💙A ESTE POST ENTRAS EN EL SORTEO DEL NUEVO GALAXY 📲\n\n¿Preparados para una nueva era del móvil? #GalaxyAI está al caer✨y te lo contaremos todo en primicia \n\n⚡¡No te olvides de seguirnos!⚡ \n\nÚnete al #SamsungUnpacked el 17 de enero de 2024 a las 19h🔴DIRECTO",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung España",
                "screenName" : "@SamsungEspana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Enterprise software"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Graphics software"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Home entertainment"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "MacOS"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Video conferencing"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Open source"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tablets"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer certification"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer programming"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Google"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-10 08:34:13"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Kay Bear",
                "screenName" : "@cheergrl01hi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-11 09:16:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742481228949749795",
                "tweetText" : "¿Estás preparado para una nueva era del móvil? #GalaxyAI está al caer✨\n\nÚnete al #SamsungUnpacked el 17 de enero de 2024 a las 19h.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung España",
                "screenName" : "@SamsungEspana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-11 09:14:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1743317892022579566",
                "tweetText" : "The human brain holds a lot of information, most of them are from what we learned during our grade school days. Take this quiz to see how much you remember!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Healthy Gem",
                "screenName" : "@TheHealthyGem"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "read"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "the way"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-11 09:15:28"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Kay Bear",
                "screenName" : "@cheergrl01hi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "enjoy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "season"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "unique"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "read"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "field"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "performance"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-12 17:16:19"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742481228949749795",
                "tweetText" : "¿Estás preparado para una nueva era del móvil? #GalaxyAI está al caer✨\n\nÚnete al #SamsungUnpacked el 17 de enero de 2024 a las 19h.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung España",
                "screenName" : "@SamsungEspana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-15 15:43:37"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742481228949749795",
                "tweetText" : "¿Estás preparado para una nueva era del móvil? #GalaxyAI está al caer✨\n\nÚnete al #SamsungUnpacked el 17 de enero de 2024 a las 19h.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung España",
                "screenName" : "@SamsungEspana"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cameras and camcorders"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Cell phones"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-16 16:47:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Hevito",
                "screenName" : "@Hevitostore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "view"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "design"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "days"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "super"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "change"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "challenge"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Spain"
                }
              ],
              "impressionTime" : "2024-01-16 16:47:48"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1734135179831390293",
                "tweetText" : "🤩 30 years of dreaming\n🤯 2 years of gamedev\n🏠 18 different buildings\n🏹 100s of arrows\n🐙 1 big bad boss\n\n➡️Wishlist on Steam: https://t.co/dcWIkQ7dK3 https://t.co/lAywPHIDeB",
                "urls" : [
                  "https://t.co/dcWIkQ7dK3"
                ],
                "mediaUrls" : [
                  "https://t.co/lAywPHIDeB"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Settlings",
                "screenName" : "@TheSettlings"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer programming"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2024-01-17 17:39:07"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747634827212243036",
                "tweetText" : "C3 Generative AI for Manufacturing is a unified knowledge source that provides fast and accurate answers to personnel in manufacturing operations.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "C3 AI",
                "screenName" : "@C3_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "B2B"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 09:29:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033846673808",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-22 09:18:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1746155133900144743",
                "tweetText" : "From AI to robotics, cutting-edge 4IR technologies are revolutionizing every aspect of our business and operations\n\nLearn how Aramco’s digital transformation is shaping the workforce of the future👇\n\n#aramco",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2024-01-22 09:29:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1745420885698183267",
                "tweetText" : "Profiteer tijdens de Warme Winter Weken bij Auping! Nu 15% voordeel op bijna ons hele assortiment 💙",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Auping",
                "screenName" : "@AupingNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 12:36:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1746155133900144743",
                "tweetText" : "From AI to robotics, cutting-edge 4IR technologies are revolutionizing every aspect of our business and operations\n\nLearn how Aramco’s digital transformation is shaping the workforce of the future👇\n\n#aramco",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 12:35:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033934762079",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-22 12:03:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1748946614155170278",
                "tweetText" : "🍳 Unlock the secret to perfectly steamed eggs with our Microwave Egg Cooker! Experience the convenience of retaining the natural goodness and nutrients of eggs while effortlessly preparing a healthy and delicious meal in just minutes. 👇 👇\n✅Click on: https://t.co/CPVYPmevAQ https://t.co/G3uGRnl7jn",
                "urls" : [
                  "https://t.co/CPVYPmevAQ"
                ],
                "mediaUrls" : [
                  "https://t.co/G3uGRnl7jn"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kay Bear",
                "screenName" : "@cheergrl01hi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "educational"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 12:03:36"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033934762079",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-22 22:03:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Palutia",
                "screenName" : "@PalutiaStore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "led"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "games"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 16:20:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143034085786091",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app. Wat kost gokken jou? Stop op tijd. 18+",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 16:20:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1741565261902426224",
                "tweetText" : "2023 marked 90 years of prosperity 🎊\nWith pivotal achievements, we continued our journey of excellence\n\nDiscover some of our milestones 🎥\n\n#aramco https://t.co/C2aSsDlZNd",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/C2aSsDlZNd"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 16:21:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "OVERDENKWERK",
                "screenName" : "@OVERDENKWERK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HBO"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-22 16:21:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1705056667107516797",
                "tweetText" : "😤Are you tired of water splashing everywhere in your bathroom and kitchen? 😃Say goodbye to the hassle with Silicone Water Retaining Strip, designed to keep your home dry and free from moisture!\n\nGet it now👉 https://t.co/X7K2EcaHZ7 https://t.co/6DsKpYSfeB",
                "urls" : [
                  "https://t.co/X7K2EcaHZ7"
                ],
                "mediaUrls" : [
                  "https://t.co/6DsKpYSfeB"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Amyhome",
                "screenName" : "@amyhome_co"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "size"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "door"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "led"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "brothers"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "house"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "games"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "economic"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "leak"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "child"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-01-22 16:20:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747463829154402705",
                "tweetText" : "💥Easily help you solve the blockage problem.\n\n🛒Get yours 👉 https://t.co/Dwe6dt470y https://t.co/QqLhX3D0yi",
                "urls" : [
                  "https://t.co/Dwe6dt470y"
                ],
                "mediaUrls" : [
                  "https://t.co/QqLhX3D0yi"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Jyvron",
                "screenName" : "@Jyvron_com"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "child"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "games"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "economic"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "leak"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "brothers"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "door"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "led"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-22 16:21:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747882061212405944",
                "tweetText" : "It's time to deep clean every corner of your home\n🎁Get it👉 https://t.co/E3Lt2FDr4H https://t.co/p7Ly1XTVRb",
                "urls" : [
                  "https://t.co/E3Lt2FDr4H"
                ],
                "mediaUrls" : [
                  "https://t.co/p7Ly1XTVRb"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Otelory",
                "screenName" : "@OteloryShop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fresh"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "future"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "deep"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "dark"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "furniture"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "air"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "design"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "pick"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "mini"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "tool"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "incredible"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modern"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "create"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-23 12:12:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Lotify",
                "screenName" : "@Lotifyshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "days"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "special"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "simple"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "future"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "match"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "light"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "training"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "stand"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-23 12:12:50"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Palutia",
                "screenName" : "@PalutiaStore"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "deep"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "professional"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "shape"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "images"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "popular"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "modern"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "students"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "changing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "event"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-23 14:02:44"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Keppyar",
                "screenName" : "@Keppyar"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "long-lasting"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "silent"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2023-11-16 13:54:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1723510737362899122",
                "tweetText" : "\"My neck is pain free &amp; my hair still look great!\"🥰\n👉 https://t.co/d85hs3aeDm https://t.co/hiVSZsqxCS",
                "urls" : [
                  "https://t.co/d85hs3aeDm",
                  "https://t.co/hiVSZsqxCS"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Cepeio",
                "screenName" : "@Cepeio"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "explore"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "development"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-16 13:53:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Huravo",
                "screenName" : "@Huravocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "notes"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "background"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "classic"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "included"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-16 13:55:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1720651549112705406",
                "tweetText" : "Revamp your wardrobe storage for a clutter-free, tidy closet! 🌟👚\n👉 https://t.co/DWtq9zRTjW https://t.co/toWJ3jLTnk",
                "urls" : [
                  "https://t.co/DWtq9zRTjW"
                ],
                "mediaUrls" : [
                  "https://t.co/toWJ3jLTnk"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Filzime",
                "screenName" : "@Filzime"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "light"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "data"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "22"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "15"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "performance"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "public"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "school"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-16 10:31:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1723973979688321380",
                "tweetText" : "Black Friday bij Auping! Nu 20% voordeel op bijna ons hele assortiment 🔥",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Auping",
                "screenName" : "@AupingNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-16 10:31:28"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Indch",
                "screenName" : "@IndchCom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nice"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-24 10:43:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1741565261902426224",
                "tweetText" : "2023 marked 90 years of prosperity 🎊\nWith pivotal achievements, we continued our journey of excellence\n\nDiscover some of our milestones 🎥\n\n#aramco https://t.co/C2aSsDlZNd",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/C2aSsDlZNd"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2024-01-24 10:54:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747190529266192445",
                "tweetText" : "Converting virtually any drill into a high capacity pump. Convenient installation and high efficiency!\n\nGet it now👉https://t.co/iPRF8JU4G5 https://t.co/KnpM2VRqii",
                "urls" : [
                  "https://t.co/iPRF8JU4G5"
                ],
                "mediaUrls" : [
                  "https://t.co/KnpM2VRqii"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fizboz",
                "screenName" : "@Fizboz_co"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "tools"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "phone"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "school"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "kids"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "door"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "car"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "parents"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-01-24 10:54:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1749291239210647923",
                "tweetText" : "🔍The Universal Remote Control Replicator is the easiest and least expensive way to copy any wireless remote, car key, garage door opener, and more! 🚗 https://t.co/wtiiJHGFVI\n🛒𝗚𝗲𝘁 𝘆𝗼𝘂𝗿𝘀👉 https://t.co/eBaqZ8gbqp",
                "urls" : [
                  "https://t.co/wtiiJHGFVI"
                ],
                "mediaUrls" : [
                  "https://t.co/eBaqZ8gbqp"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Otelory",
                "screenName" : "@OteloryShop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fresh"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "love"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "match"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "dark"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "money"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "digital"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-24 09:45:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033846673808",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-24 09:45:12"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1740039681889214500",
                "tweetText" : "Lets be honest, everything we learn in school we quickly forget right after the exam. How many of these historical figures do you actually remember?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Explored History",
                "screenName" : "@XploredHistory"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "read"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "family"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "day"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "twitter"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2024-01-25 10:47:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033846673808",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-01-25 10:31:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748330245176877339",
                "tweetText" : "TONZON Thermoskussens maken uw vloer nog warmer dan de lucht erboven. Sinds 1980 de meest effectieve en ecologische #vloerisolatie. Ook geschikt bij bodemisolatie en nieuwbouwvloeren. Beperkt warmteverlies met 65% tot 94%. https://t.co/POXpdTS9Rh https://t.co/BvOn7jUbp6",
                "urls" : [
                  "https://t.co/POXpdTS9Rh"
                ],
                "mediaUrls" : [
                  "https://t.co/BvOn7jUbp6"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TONZON",
                "screenName" : "@Tonzon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2024-01-25 14:05:31"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747811613623611799",
                "tweetText" : "🏘Weather Stripping Door Seal Strip keep your house warm and cozy in the cold winter!\n\n🛒Get it👉 https://t.co/99oTkNxEyj https://t.co/Jq7DG0KFqf",
                "urls" : [
                  "https://t.co/99oTkNxEyj"
                ],
                "mediaUrls" : [
                  "https://t.co/Jq7DG0KFqf"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Merlotu",
                "screenName" : "@MerlotuSt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "game"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "perfect"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "gap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "movies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "video"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "secure"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "content"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "save"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fresh"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "minutes"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apply"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "wrong"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "office"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "special"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "strong"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "women"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "water"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "closed"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "summer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-26 10:43:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1749348944851964192",
                "tweetText" : "💦 Difficult to clean 🚿 Just a quick spray and wipe clean! It's like living in a new home! 🌪\n🛒Get it👉 https://t.co/AMRKXXZmuD https://t.co/OAHy0SC9i8",
                "urls" : [
                  "https://t.co/AMRKXXZmuD"
                ],
                "mediaUrls" : [
                  "https://t.co/OAHy0SC9i8"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Rotlux",
                "screenName" : "@RotluxSt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "experience"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "video"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "office"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fresh"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-26 11:05:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747637366611677249",
                "tweetText" : "Use C3 Generative AI for Intelligence to accelerate intelligence cycles and improve investigation accuracy.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "C3 AI",
                "screenName" : "@C3_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "B2B"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-26 11:05:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742904836931158256",
                "tweetText" : "What if it was your daughter? \n\nWhat if it was your brother?\n\nWhat if it was your mother? \n\nWhat if it was your baby? \n\nMore than 100 Israelis are being held hostage by Hamas terrorists in Gaza. \n\nEvery minute counts. \n\n#BringThemHomeNow https://t.co/AHNoEmWvOl",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/AHNoEmWvOl"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Israel ישראל 🇮🇱",
                "screenName" : "@Israel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Adult education"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Graduate school"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2024-01-26 11:05:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1750125953953538463",
                "tweetText" : "@klimaatbeleid #netcongestie:  #klimaatneutraal en comfortabel wonen met vloerverwarming en warmtepomp kan alleen met betere vloerisolatie dan de huidige nieuwbouwnorm (Rc=3,7 m²K/W).\n@milieucentraal adviseert bij #vloerverwarming minimaal Rc 5 m²K/W. https://t.co/POXpdTS9Rh https://t.co/zAzlyWJ4bH",
                "urls" : [
                  "https://t.co/POXpdTS9Rh"
                ],
                "mediaUrls" : [
                  "https://t.co/zAzlyWJ4bH"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TONZON",
                "screenName" : "@Tonzon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-26 11:05:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1750481973464772756",
                "tweetText" : "Top vakantie naar de Azoren\n\nGa op reis naar één van de mooiste plekjes van de wereld\n\n8 dagen inclusief vlucht vanaf Schiphol met TUI fly, zeer goed beoordeeld viersterren appartement en transfer",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DutchFlyGuys",
                "screenName" : "@DutchFlyGuys"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2024-01-26 11:05:44"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747634827212243036",
                "tweetText" : "C3 Generative AI for Manufacturing is a unified knowledge source that provides fast and accurate answers to personnel in manufacturing operations.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "C3 AI",
                "screenName" : "@C3_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "B2B"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-26 15:21:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1650495651501813765",
                "tweetText" : "Speed up your development with C++ TeX Manipulation Library. Try it for free!  #CPP #API #Programming\n\nhttps://t.co/8Mt0MMP1u7",
                "urls" : [
                  "https://t.co/8Mt0MMP1u7"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StackOverflow"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2024-01-26 15:21:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143293771894843",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-29 09:35:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1650495651501813765",
                "tweetText" : "Speed up your development with C++ TeX Manipulation Library. Try it for free!  #CPP #API #Programming\n\nhttps://t.co/8Mt0MMP1u7",
                "urls" : [
                  "https://t.co/8Mt0MMP1u7"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StackOverflow"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-29 17:01:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1650495651413729283",
                "tweetText" : "Do you need C++ TeX Manipulation Library? Try it for free!! \n\n#CPP #API #Programming\n\nhttps://t.co/kmEkWYaeI3",
                "urls" : [
                  "https://t.co/kmEkWYaeI3"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StackOverflow"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2024-01-29 17:01:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747635848592429417",
                "tweetText" : "C3 Generative AI for Reliability is a unified knowledge source that helps personnel find fast and accurate answers, improving uptime, operational productivity, and safety.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "C3 AI",
                "screenName" : "@C3_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "B2B"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-29 17:01:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747468316522709150",
                "tweetText" : "🎶 Elevate your music experience with our sleek wireless headset! 💦 Enjoy hours of music without earbud damage, and revel in perfect sound quality. 😍 Stay safe with its innovative design and take it anywhere – it's waterproof! \nGet yours now 👉 https://t.co/ksktSERWcP https://t.co/OjV3xCnWQr",
                "urls" : [
                  "https://t.co/ksktSERWcP"
                ],
                "mediaUrls" : [
                  "https://t.co/OjV3xCnWQr"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kay Bear",
                "screenName" : "@cheergrl01hi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "quality"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "quick"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "series"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "social"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fun"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "digital"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "book"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "summer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "season"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "heart"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-29 17:01:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1746740084718596470",
                "tweetText" : "🔥 Keep winter at bay with the Weather Stripping Door Seal Strip! Say goodbye to drafts and chilly breezes as this simple yet effective strip seals your door, ensuring your home stays warm and cozy throughout the cold season❄️🚪\n\n🛒Get it👉 https://t.co/roU0pLpEzU https://t.co/OgtDoJ6J13",
                "urls" : [
                  "https://t.co/roU0pLpEzU"
                ],
                "mediaUrls" : [
                  "https://t.co/OgtDoJ6J13"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kay Bear",
                "screenName" : "@cheergrl01hi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "sign"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "summer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "control"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "explore"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "break"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-29 16:51:12"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1751464158669816047",
                "tweetText" : "💪With the benefit of our back brace, you will have a straight posture and be more confident, healthy, and younger.\n😎 Enjoy a wonderful life with a better posture.\n🛒 Get yours: https://t.co/UV393YoFT0 https://t.co/BIZeQAzd51",
                "urls" : [
                  "https://t.co/UV393YoFT0"
                ],
                "mediaUrls" : [
                  "https://t.co/BIZeQAzd51"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Rotlux",
                "screenName" : "@RotluxSt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "living"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cool"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-30 13:03:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1750440952039108695",
                "tweetText" : "Wil jij werken op het snijvlak van bedrijfsleven, politiek en samenleving? Vind jij verduurzaming en continuïteit van de bouwproductie ook zo belangrijk? Als onze Adviseur Markt en Overheid ben jij dé intermediair tussen bouwbedrijven, overheden en opdrachtgevers in de sector. 👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Koninklijke Bouwend Nederland",
                "screenName" : "@BouwendNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Utrecht"
                }
              ],
              "impressionTime" : "2024-01-30 13:28:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1750581155219358060",
                "tweetText" : "Neem heerlijk comfortabel de trein naar Disneyland Parijs!\n\nDe prijzen starten bij €70 voor een retourtje rechtstreeks naar de ingang van het park!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DutchFlyGuys",
                "screenName" : "@DutchFlyGuys"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2024-01-30 13:27:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747956520149791176",
                "tweetText" : "Create videos within ChatGPT 🪄 \nTry our VideoMaker on the GPT Store &gt;&gt;\n\nChatGPT Plus required ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "invideo",
                "screenName" : "@invideoOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-30 13:03:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1749991972599652743",
                "tweetText" : "😎 Helps you waterproof, seal cracks, quickly leak-proof after only 10 seconds\nGet &gt;&gt; https://t.co/FoPJT8gIif https://t.co/JL0vZuyTIZ",
                "urls" : [
                  "https://t.co/FoPJT8gIif"
                ],
                "mediaUrls" : [
                  "https://t.co/JL0vZuyTIZ"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lotevia",
                "screenName" : "@Loteviacom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "control"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "developed"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "time"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "living"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "helps"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-30 13:03:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143033846673808",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2024-01-30 13:47:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1741565261902426224",
                "tweetText" : "2023 marked 90 years of prosperity 🎊\nWith pivotal achievements, we continued our journey of excellence\n\nDiscover some of our milestones 🎥\n\n#aramco https://t.co/C2aSsDlZNd",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/C2aSsDlZNd"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-30 13:27:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1751544804737970350",
                "tweetText" : "Investeer #spaargeld slim in vloerisolatie van TONZON. Het hoogste rendement dankzij het best isolerend effect (Rc 5 - 7 m²K/W) en krijg de warmste vloer en droge kruipruimte op de koop toe. Ook voor EPS-vloeren en woningen met bodemisolatie https://t.co/POXpdTS9Rh https://t.co/0wUf66lsle",
                "urls" : [
                  "https://t.co/POXpdTS9Rh"
                ],
                "mediaUrls" : [
                  "https://t.co/0wUf66lsle"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TONZON",
                "screenName" : "@Tonzon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2024-01-30 13:03:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1716308927837614438",
                "tweetText" : "After I bought this toy for my child, he stayed away from iPad, Tablet and TV 💥\n\n🛒Get it here 👉 https://t.co/aXlOW73nGs https://t.co/OB0dVbMDPV",
                "urls" : [
                  "https://t.co/aXlOW73nGs"
                ],
                "mediaUrls" : [
                  "https://t.co/OB0dVbMDPV"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fizboz",
                "screenName" : "@Fizboz_co"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "team"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "active"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "release"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cool"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-01-30 13:03:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742143034085786091",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app. Wat kost gokken jou? Stop op tijd. 18+",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-01-30 13:27:31"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "OVERDENKWERK",
                "screenName" : "@OVERDENKWERK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HBO"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-02-01 13:43:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829117920153683",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-02-01 13:42:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1750873979760304504",
                "tweetText" : "Altijd kans op spanning met live blackjack en roulette. Pak die kans bij Kansino! Hét leukste online casino van Nederland.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kansino",
                "screenName" : "@kansino_nl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-02-01 13:44:14"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829117136089122",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app. Wat kost gokken jou? Stop op tijd. 18+",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-02-04 18:27:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1751795166258905380",
                "tweetText" : "Hey Human, yes YOU! Still slogging through test case creation like it's the Stone Age? 🦖 Time to emerge from beneath that rock 🌪️ as smarter humans let RoostGPT handle test case writing  ✍️ , while they soak up the sun at the beach 🏖️.#GPT #generativeai #softwaretesting #llms",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roost.ai",
                "screenName" : "@Roost"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-02-04 18:27:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1753488514141041028",
                "tweetText" : "With unmatched performance per dollar and better availability, the new NVIDIA L40S GPUs in Supermicro's systems are a versatile solution that's capable of meeting the demands for LLMs. Click to learn more.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Supermicro",
                "screenName" : "@Supermicro_SMCI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nvidia"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-02-04 18:27:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730334432916316565",
                "tweetText" : "RT @HPE_GreenLake: You need a hybrid cloud as unique as your business.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HPE",
                "screenName" : "@HPE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer networking"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2024-02-04 18:27:18"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708814093367615809",
                "tweetText" : "Speel mee in ons online casino en word ook Koning TOTO! 👑",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TOTO",
                "screenName" : "@TOTO_NL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2023-11-20 16:48:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874483925484012",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2023-11-20 15:18:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676120602853535",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:36:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Vextoity",
                "screenName" : "@Vextoity"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "building"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "community"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "impact"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "model"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:36:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Cesselin",
                "screenName" : "@Cesselin_shop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "coming"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "special"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "fantastic"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "art"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "products"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "version"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "care"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "house"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "real"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "model"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:36:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "VazuVision",
                "screenName" : "@VazuVision"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "write"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "dangerous"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "special"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "care"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "night"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "learning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "art"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "happy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "coming"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "talk"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "easy"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "set"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "house"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "amazing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "real"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "personal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "parents"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "school"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "version"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:36:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Caplami",
                "screenName" : "@Caplami"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "feel"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "lot"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:32:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726503266245324829",
                "tweetText" : "Black Friday? Gewoon een goeie deal.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "98980",
                "name" : "#groetenvanben20231120",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Ben",
                "screenName" : "@groetenvanben"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:18:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676127561019552",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-20 15:36:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1680019788884742145",
                "tweetText" : "Stop paying for dedicated infrastructure capacity you don't use. \n\nGet on board with #baremetal configurations that are flexible and tweakable to your heart's content.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Equinix Metal",
                "screenName" : "@equinixmetal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@GoogleCloudTech"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-21 21:07:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874482801320282",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 10:34:09"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726147847081603466",
                "tweetText" : "How do we advance and deploy Industrial Internet of Things to improve operations?\n\n#aramco90th\n#aramco https://t.co/kJShlto8IO",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/kJShlto8IO"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-22 16:15:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1696793356360102057",
                "tweetText" : "GEPATENTEERD ondershirt voor heren dat beschermt tegen zweet | Zweet dringt niet meer door in je bovenkleding | Voordelen: je kunt je bovenkleding langer dragen, hoeft deze minder vaak te wassen &amp; strijken en daardoor blijft deze langer mooi!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hygienicshirt",
                "screenName" : "@hygienicshirt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2023-11-22 22:47:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726976761307557996",
                "tweetText" : "Using conversational AI, brands can tailor messages they know will resonate with customers\n\nPartner Content by @Infobip",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FT Partner Content",
                "screenName" : "@ft_content"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OpenAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@verge"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gizmodo"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WIRED"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TechCrunch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@engadget"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@GoogleAI"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-22 22:47:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1722285913634488776",
                "tweetText" : "We generen ons een beetje om toe te geven dat we ons deze geniale verborgen bijzonderheden nu pas realiseren.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HomeTalk",
                "screenName" : "@HomeTalk_DIY"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                }
              ],
              "impressionTime" : "2023-11-22 22:47:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1707974342938918976",
                "tweetText" : "🏃𝗪𝗵𝘆 These are the 𝗠𝗼𝘀𝘁 𝗣𝗼𝗽𝘂𝗹𝗮𝗿 Comfortable Shoes\n✅ 𝗢𝗽𝘁𝗶𝗺𝗮𝗹 𝗗𝗲𝘀𝗶𝗴𝗻 for Wide Feet.\n✅ Supreme 𝗖𝗼𝗺𝗳𝗼𝗿𝘁 &amp; 𝗦𝘂𝗽𝗽𝗼𝗿𝘁.\n✅ 𝗙𝗿𝗲𝗲 𝗦𝗵𝗶𝗽𝗽𝗶𝗻𝗴 &amp; Hassle-Free Returns.\n✅ 𝗣𝗼𝗱𝗶𝗮𝘁𝗿𝗶𝘀𝘁-𝗘𝗻𝗱𝗼𝗿𝘀𝗲𝗱 Footwear.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Canles",
                "screenName" : "@canlesofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 22:48:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676121269584011",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 22:48:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1714973088775913661",
                "tweetText" : "Napkin for iOS is coming.\n\nWe’re building the first app for mindful reflection on ideas.\n\nMore and more pioneers are invited to the private beta every week. Get early access and change the way you think. 👉 https://t.co/44AQpncPOJ https://t.co/F7a9nAmBOS",
                "urls" : [
                  "https://t.co/44AQpncPOJ"
                ],
                "mediaUrls" : [
                  "https://t.co/F7a9nAmBOS"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Napkin",
                "screenName" : "@napkin_ideas"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ShaneAParrish"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@naval"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@lexfridman"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 22:48:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726465394519499216",
                "tweetText" : "Exposome is a fully open access, peer reviewed journal looking for new work that extends our understanding of the human exposome. Interested in contributing to cutting edge research in a new field? Discover why Exposome is the right home for your work:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Oxford Journals",
                "screenName" : "@OxfordJournals"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@openscience"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 22:48:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1727037122903781727",
                "tweetText" : "Rewards for Simple Tasks! Familiarize yourself with the tasks and proceed to complete them.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "AndrewGreen.eth",
                "screenName" : "@MelissaOlguin14"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Online gaming"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-11-22 22:47:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1724432014198067311",
                "tweetText" : "Our spirit of exploration can be traced in our history and continues to propel us into the future 🪨📍\n\n#aramco90th\n#aramco",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                }
              ],
              "impressionTime" : "2023-11-22 22:46:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1708874483925484012",
                "tweetText" : "Beleef de totale wed-ervaring zelf. Je favoriete sporten, livestreaming &amp; exclusieve spellen. Alles in één app.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LiveScore Bet NL",
                "screenName" : "@LiveScoreBetNL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EURO2024"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AFCAjax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FIFAWorldCup"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ChampionsLeague"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 22:45:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1699380925392380239",
                "tweetText" : "The MLOps stack component for experiment tracking\n\n🔹 Automate and standardize tracking as your modeling team grows\n\n🔹 Collaborate on models and results with your team and across the org\n\n🔹Integrate with any MLOps stack\n\nLearn more ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "neptune.ai",
                "screenName" : "@neptune_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AndrewYNg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kdnuggets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@drfeifei"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@KirkDBorne"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ylecun"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "app users - URL manual"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "App URL"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                }
              ],
              "impressionTime" : "2023-11-22 22:47:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1714451252892090849",
                "tweetText" : "Love this T-shirt!\nOrder here: https://t.co/JuzmljejzM https://t.co/FudBEKUBfS",
                "urls" : [
                  "https://t.co/JuzmljejzM"
                ],
                "mediaUrls" : [
                  "https://t.co/FudBEKUBfS"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "May The 4th Tee",
                "screenName" : "@maythe_4thtee"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@starwars"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2023-11-22 22:48:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676122779435452",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 14:32:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1721850855069032573",
                "tweetText" : "#aramco continues to deliver robust Q3 earnings while progressing its growth strategy\n\n#AramcoResults\n#aramco90th",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2023-11-22 15:16:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1713676121437552799",
                "tweetText" : "Omdat je als ondernemer altijd vol door wilt, krijg je standaard SmartWifi bij Zakelijk Internet Xtra.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ziggo Zakelijk",
                "screenName" : "@ZiggoZakelijk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NUnl"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@phvmulligen"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PhRemarque"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@steeph"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2023-11-22 15:16:08"
            }
          ]
        }
      }
    }
  }
]