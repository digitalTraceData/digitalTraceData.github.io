window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1570683392894574592",
      "ownerUserId" : "1447908998859079690",
      "createdAt" : "2022-09-16T07:57:57.404Z"
    }
  }
]