window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1447908998859079690"
    }
  }
]