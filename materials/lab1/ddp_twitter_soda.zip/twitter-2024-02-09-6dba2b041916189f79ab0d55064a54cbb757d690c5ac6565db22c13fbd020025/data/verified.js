window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1447908998859079690",
      "verified" : false
    }
  }
]