window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MonaSmitte/lists/data-infographics"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MonaSmitte/lists/tech-research-science"
    }
  }
]