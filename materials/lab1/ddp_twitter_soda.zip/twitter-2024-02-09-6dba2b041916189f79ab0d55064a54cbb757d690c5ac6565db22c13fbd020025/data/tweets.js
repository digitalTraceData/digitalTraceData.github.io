window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1755896748919202161"
          ],
          "editableUntil" : "2024-02-09T11:09:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/cEL0JAPxjL",
            "expanded_url" : "https://cdh.uu.nl/",
            "display_url" : "cdh.uu.nl",
            "indices" : [
              "77",
              "100"
            ]
          },
          {
            "url" : "https://t.co/pYvDk3tZBT",
            "expanded_url" : "https://github.com/CentreForDigitalHumanities/fair-dash",
            "display_url" : "github.com/CentreForDigit…",
            "indices" : [
              "127",
              "150"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "192"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1755896746222174634",
      "id_str" : "1755896748919202161",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1755896748919202161",
      "in_reply_to_status_id" : "1755896746222174634",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 09 10:09:42 +0000 2024",
      "favorited" : false,
      "full_text" : "The dashboard is based on earlier work by the Centre for Digital Humanities (https://t.co/cEL0JAPxjL) at Utrecht University.\n\n🔗https://t.co/pYvDk3tZBT\n\n🫂 Thanks to them for sharing their work!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1755896746222174634"
          ],
          "editableUntil" : "2024-02-09T11:09:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/t8QadKrTwl",
            "expanded_url" : "https://fair.odissei-soda.nl/",
            "display_url" : "fair.odissei-soda.nl",
            "indices" : [
              "233",
              "256"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1755896746222174634/photo/1",
            "indices" : [
              "257",
              "280"
            ],
            "url" : "https://t.co/JATxBoBen0",
            "media_url" : "http://pbs.twimg.com/media/GF4wlRAWYAAw9J1.jpg",
            "id_str" : "1755894321499234304",
            "id" : "1755894321499234304",
            "media_url_https" : "https://pbs.twimg.com/media/GF4wlRAWYAAw9J1.jpg",
            "sizes" : {
              "large" : {
                "w" : "1682",
                "h" : "722",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "515",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "292",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JATxBoBen0"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "280"
      ],
      "favorite_count" : "5",
      "id_str" : "1755896746222174634",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1755896746222174634",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 09 10:09:41 +0000 2024",
      "favorited" : false,
      "full_text" : "✨ We have a shiny new FAIR projects dashboard!\n\n🔎💻 Check the links to the Github repos for all our projects, by topics, and including info on the adherence to FAIR principles (licenses, contact info, availability of description…) \n\n🔗https://t.co/t8QadKrTwl https://t.co/JATxBoBen0",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1755896746222174634/photo/1",
            "indices" : [
              "257",
              "280"
            ],
            "url" : "https://t.co/JATxBoBen0",
            "media_url" : "http://pbs.twimg.com/media/GF4wlRAWYAAw9J1.jpg",
            "id_str" : "1755894321499234304",
            "id" : "1755894321499234304",
            "media_url_https" : "https://pbs.twimg.com/media/GF4wlRAWYAAw9J1.jpg",
            "sizes" : {
              "large" : {
                "w" : "1682",
                "h" : "722",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "515",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "292",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JATxBoBen0"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749806699421303131"
          ],
          "editableUntil" : "2024-01-23T15:50:01.635Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "Netherlands eScience Center @akademienl.social",
            "screen_name" : "eScienceCenter",
            "indices" : [
              "98",
              "113"
            ],
            "id_str" : "278980371",
            "id" : "278980371"
          },
          {
            "name" : "CBS",
            "screen_name" : "statistiekcbs",
            "indices" : [
              "115",
              "129"
            ],
            "id_str" : "61733587",
            "id" : "61733587"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1749806699421303131",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1749806699421303131",
      "created_at" : "Tue Jan 23 14:50:01 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: What's more: in this programme we work together with experts from the Netherlands @eScienceCenter, @statistiekcbs, @centerd…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749806661395722416"
          ],
          "editableUntil" : "2024-01-23T15:49:52.569Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "Erasmus University",
            "screen_name" : "erasmusuni",
            "indices" : [
              "105",
              "116"
            ],
            "id_str" : "52693210",
            "id" : "52693210"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1749806661395722416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1749806661395722416",
      "created_at" : "Tue Jan 23 14:49:52 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: 🥁The applications for SICSS-ODISSEI Summer School 2024 are open, apply by February 28.\n\n📍@erasmusuni Rotterdam, 17-28 June…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749366865317531967"
          ],
          "editableUntil" : "2024-01-22T10:42:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "269"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1749366863572672825",
      "id_str" : "1749366865317531967",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1749366865317531967",
      "in_reply_to_status_id" : "1749366863572672825",
      "created_at" : "Mon Jan 22 09:42:17 +0000 2024",
      "favorited" : false,
      "full_text" : "📚 In the post, we guide you through:\n\n🔧 How to train and fit an unsupervised word-embedding model\n\n📊 How to use the resulting word embeddings for cool stuff, e.g., getting analogies or most similar words\n\nAnd as a bonus, we give some tips to improve model performance 🚀",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749366863572672825"
          ],
          "editableUntil" : "2024-01-22T10:42:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/GCRWgiLqpz",
            "expanded_url" : "https://odissei-soda.nl/tutorials/post-6/",
            "display_url" : "odissei-soda.nl/tutorials/post…",
            "indices" : [
              "208",
              "231"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "233"
      ],
      "favorite_count" : "1",
      "id_str" : "1749366863572672825",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1749366863572672825",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 22 09:42:16 +0000 2024",
      "favorited" : false,
      "full_text" : "🧠 In the era of large language models, what about a natural language processing model you can train yourself?\n\n📖 Check our newblogpost to learn how!\n\n➡ We show you how to train a fastText model using Python: https://t.co/GCRWgiLqpz 🐍",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1746867765103726601"
          ],
          "editableUntil" : "2024-01-15T13:11:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "274"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1746867763275079883",
      "id_str" : "1746867765103726601",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1746867765103726601",
      "in_reply_to_status_id" : "1746867763275079883",
      "created_at" : "Mon Jan 15 12:11:45 +0000 2024",
      "favorited" : false,
      "full_text" : "👐The approach is hands-on, and there will be guided practicals focusing on using SURF’s supercomputing capabilities.\n\n📚Topics covered include: efficient programming, parallel computing, and translating R workflows into a supercomputer environment\n\n📅We hope to see you there!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1746867763275079883"
          ],
          "editableUntil" : "2024-01-15T13:11:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SURF-coöperatie",
            "screen_name" : "SURF_NL",
            "indices" : [
              "132",
              "140"
            ],
            "id_str" : "19232850",
            "id" : "19232850"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/JmMwZ8OmQZ",
            "expanded_url" : "https://www.surf.nl/en/agenda/cluster-computing-for-social-scientists-with-r",
            "display_url" : "surf.nl/en/agenda/clus…",
            "indices" : [
              "163",
              "186"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "2",
      "id_str" : "1746867763275079883",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1746867763275079883",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 15 12:11:44 +0000 2024",
      "favorited" : false,
      "full_text" : "🚀 Join us on February 16, 2024, for a hands-on workshop on Cluster Computing for Social Scientists with R! 🎓Organized together with @SURF_NL \n\n🔗Registration info: https://t.co/JmMwZ8OmQZ\n\nMore info on the next tweet 👇",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1736680648138441047"
          ],
          "editableUntil" : "2023-12-18T10:31:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tilburg University",
            "screen_name" : "TilburgU",
            "indices" : [
              "136",
              "145"
            ],
            "id_str" : "50655273",
            "id" : "50655273"
          },
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "166",
              "179"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "6",
      "id_str" : "1736680648138441047",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1736680648138441047",
      "created_at" : "Mon Dec 18 09:31:47 +0000 2023",
      "favorited" : false,
      "full_text" : "📢From December, we have a new team member: Nadya Ali, who joins our team as a SoDa Fellow.\n\n📚Nadya is doing a PhD in Neuropsychology at @TilburgU. During her stay at @ODISSEI_SoDa , she'll be working on the effects of poverty on children's brain development.\n\n👫Welcome, Nadya!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1735588071947505902"
          ],
          "editableUntil" : "2023-12-15T10:10:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/DTD73juNyu",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1702318963089404034",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "83",
              "106"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1735587678496665752",
      "id_str" : "1735588071947505902",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1735588071947505902",
      "in_reply_to_status_id" : "1735587678496665752",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 15 09:10:16 +0000 2023",
      "favorited" : false,
      "full_text" : "And if you want to know more about the fellowship, here you will find more info 👇\n\nhttps://t.co/DTD73juNyu",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1735587678496665752"
          ],
          "editableUntil" : "2023-12-15T10:08:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "3",
      "id_str" : "1735587678496665752",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1735587678496665752",
      "created_at" : "Fri Dec 15 09:08:42 +0000 2023",
      "favorited" : false,
      "full_text" : "🆕New deadline SoDa fellowship!\n\nThe previous deadline was set at an unfortunate time (30th of December, apologies!). \n\n📅To avoid forcing applicants to work during the holidays, we are extending the deadline to the 12th of January.\n\nWe are looking forward to your application!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1734166887284490419"
          ],
          "editableUntil" : "2023-12-11T12:02:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Utrecht University",
            "screen_name" : "UniUtrecht",
            "indices" : [
              "72",
              "83"
            ],
            "id_str" : "33548291",
            "id" : "33548291"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/FHrOZDdhIQ",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1717492459683340332",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "257",
              "280"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "280"
      ],
      "favorite_count" : "1",
      "id_str" : "1734166887284490419",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1734166887284490419",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 11 11:02:59 +0000 2023",
      "favorited" : false,
      "full_text" : "📅This Wednesday, Raoul Schram from the SoDa team will be present at the @UniUtrecht's Open Science on Track day.\n\nHe will be talking about metasyn, our new software to generate synthetic data. You can read more about metasyn, its goals and use cases here 👇 https://t.co/FHrOZDdhIQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1734134676829118639"
          ],
          "editableUntil" : "2023-12-11T09:55:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/1XqKED5yQC",
            "expanded_url" : "https://geoflow-visualizer.github.io/geoflow-visualizer/",
            "display_url" : "geoflow-visualizer.github.io/geoflow-visual…",
            "indices" : [
              "242",
              "265"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1734134674459386227",
      "id_str" : "1734134676829118639",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1734134676829118639",
      "in_reply_to_status_id" : "1734134674459386227",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 11 08:55:00 +0000 2023",
      "favorited" : false,
      "full_text" : "📊Geoflow can be used for any international inflow/outflow data (e.g., migration or cash flows), and it allows for several visualization options. Besides:\n\n👍It is very easy to use: you only need to upload a .csv dataset.\n\n 🌐It is open source: https://t.co/1XqKED5yQC",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1734134674459386227"
          ],
          "editableUntil" : "2023-12-11T09:54:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/QL7eov3239",
            "expanded_url" : "https://odissei-soda.nl/tutorials/post-7/",
            "display_url" : "odissei-soda.nl/tutorials/post…",
            "indices" : [
              "253",
              "276"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1734134674459386227/photo/1",
            "indices" : [
              "277",
              "300"
            ],
            "url" : "https://t.co/9nHNCY35oT",
            "media_url" : "http://pbs.twimg.com/media/GBDgCDtXsAEhjWt.jpg",
            "id_str" : "1734132182497603585",
            "id" : "1734132182497603585",
            "media_url_https" : "https://pbs.twimg.com/media/GBDgCDtXsAEhjWt.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "402",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1408",
                "h" : "833",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "710",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9nHNCY35oT"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "300"
      ],
      "favorite_count" : "1",
      "id_str" : "1734134674459386227",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1734134674459386227",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 11 08:54:59 +0000 2023",
      "favorited" : false,
      "full_text" : "🆕In our last tutorial, we introduce Geoflow: a new tool to visualize international flows in an interactive way.\n\n🗺Geoflow's key feature is creating inflow/outflow maps, like this showing China's investments in fossil fuel companies\n\n🔗Check it out here! https://t.co/QL7eov3239 https://t.co/9nHNCY35oT",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1734134674459386227/photo/1",
            "indices" : [
              "277",
              "300"
            ],
            "url" : "https://t.co/9nHNCY35oT",
            "media_url" : "http://pbs.twimg.com/media/GBDgCDtXsAEhjWt.jpg",
            "id_str" : "1734132182497603585",
            "id" : "1734132182497603585",
            "media_url_https" : "https://pbs.twimg.com/media/GBDgCDtXsAEhjWt.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "402",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1408",
                "h" : "833",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "710",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9nHNCY35oT"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1733129504975917200"
          ],
          "editableUntil" : "2023-12-08T15:20:48.632Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "54",
              "65"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "71",
              "84"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1733129504975917200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1733129504975917200",
      "created_at" : "Fri Dec 08 14:20:48 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: 🧑🏻‍💻Passionate about citizen science? @ODISSEI_nl  and @ODISSEI_SoDa have produced a small piece of software to correct geo…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1719687213527580709"
          ],
          "editableUntil" : "2023-11-01T13:05:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ekSgX7Jf9G",
            "expanded_url" : "https://odissei-data.nl/en/2023/09/odissei-conference-for-social-science-in-the-netherlands-2023/",
            "display_url" : "odissei-data.nl/en/2023/09/odi…",
            "indices" : [
              "35",
              "58"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1719686827651506672",
      "id_str" : "1719687213527580709",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1719687213527580709",
      "in_reply_to_status_id" : "1719686827651506672",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 01 12:05:56 +0000 2023",
      "favorited" : false,
      "full_text" : "📌Check out the full programe here: https://t.co/ekSgX7Jf9G",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1719686827651506672"
          ],
          "editableUntil" : "2023-11-01T13:04:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "35",
              "46"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "194",
              "208"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "3",
      "id_str" : "1719686827651506672",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1719686827651506672",
      "created_at" : "Wed Nov 01 12:04:24 +0000 2023",
      "favorited" : false,
      "full_text" : "📢 Tomorrow we'll be present at the @ODISSEI_nl conference! 📢\n\n➡ Come and discuss our projects and principles, your research and how we can help in our booth in the ODISSEI Marketplace.\n\n➡ Check @ejvankesteren introduction of our work at the ODISSEI Facilities flashtalks.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717566215063839030"
          ],
          "editableUntil" : "2023-10-26T16:37:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/NKkwQa1PGO",
            "expanded_url" : "http://odissei-soda.nl",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "220",
              "243"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "253"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1717566213008543970",
      "id_str" : "1717566215063839030",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1717566215063839030",
      "in_reply_to_status_id" : "1717566213008543970",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 26 15:37:51 +0000 2023",
      "favorited" : false,
      "full_text" : "🙋This is a question we have received a few times, so we hope you find this post useful!\n\n🧰And, as always, remember: if you encounter a computational or data-intensive problem in your research, we are here to help.\n\n🌐See https://t.co/NKkwQa1PGO for more!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717566213008543970"
          ],
          "editableUntil" : "2023-10-26T16:37:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "229"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1717566210609471898",
      "id_str" : "1717566213008543970",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1717566213008543970",
      "in_reply_to_status_id" : "1717566210609471898",
      "created_at" : "Thu Oct 26 15:37:50 +0000 2023",
      "favorited" : false,
      "full_text" : "In it, we illustrate how to:\n\n🧮Use the lubridate R package to compute and work with time intervals.\n\n💻Write a small function that computes the proportion of time a given unit was present in a dataset, for an interval of interest.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717566210609471898"
          ],
          "editableUntil" : "2023-10-26T16:37:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ITNQenY3n2",
            "expanded_url" : "https://odissei-soda.nl/tutorials/post-5/",
            "display_url" : "odissei-soda.nl/tutorials/post…",
            "indices" : [
              "217",
              "240"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "240"
      ],
      "favorite_count" : "0",
      "id_str" : "1717566210609471898",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1717566210609471898",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 26 15:37:50 +0000 2023",
      "favorited" : false,
      "full_text" : "🆕New blogpost!\n\n🏘 Have you ever worked with the Dutch housing register data?\n\n🗓 Or have you ever had to compute what part of a certain interval an individual was present in a dataset?\n\nThen this blogpost is for you!\n\nhttps://t.co/ITNQenY3n2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717493149809926416"
          ],
          "editableUntil" : "2023-10-26T11:47:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/QKEWJVbOfH",
            "expanded_url" : "https://www.uu.nl/nieuws/deze-software-maakt-privacygevoelige-onderzoeksgegevens-toegankelijker",
            "display_url" : "uu.nl/nieuws/deze-so…",
            "indices" : [
              "43",
              "66"
            ]
          },
          {
            "url" : "https://t.co/kdWBYQ1J36",
            "expanded_url" : "https://github.com/sodascience/metasyn",
            "display_url" : "github.com/sodascience/me…",
            "indices" : [
              "97",
              "120"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1717492459683340332",
      "id_str" : "1717493149809926416",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1717493149809926416",
      "in_reply_to_status_id" : "1717492459683340332",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 26 10:47:31 +0000 2023",
      "favorited" : false,
      "full_text" : "See also: \n🔗Dutch version of the interview https://t.co/QKEWJVbOfH\n\n🔗Github repo for the project\nhttps://t.co/kdWBYQ1J36",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717492459683340332"
          ],
          "editableUntil" : "2023-10-26T11:44:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "124",
              "138"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/M1hP1YwslP",
            "expanded_url" : "https://www.uu.nl/en/news/this-software-makes-privacy-sensitive-research-data-more-accessible",
            "display_url" : "uu.nl/en/news/this-s…",
            "indices" : [
              "220",
              "243"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "243"
      ],
      "favorite_count" : "11",
      "id_str" : "1717492459683340332",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1717492459683340332",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 26 10:44:46 +0000 2023",
      "favorited" : false,
      "full_text" : "Our software for the generation of synthetic data, 'metasyn' has been featured in the UU website.\n\nCheck the interview with @ejvankesteren to learn about its goals, mainly making privacy sensitive data more accessible.\n\nhttps://t.co/M1hP1YwslP",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1713908620855845081"
          ],
          "editableUntil" : "2023-10-16T14:23:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/J0tEk6GgHN",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1713908261966037302",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "92",
              "115"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "1",
      "id_str" : "1713908620855845081",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1713908620855845081",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 16 13:23:52 +0000 2023",
      "favorited" : false,
      "full_text" : "❗Our next data drop-in session is this Thursday (October 19th) ❗\n\nWe hope to see you there! https://t.co/J0tEk6GgHN",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1713908265677942842"
          ],
          "editableUntil" : "2023-10-16T14:22:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/NKkwQa1PGO",
            "expanded_url" : "http://odissei-soda.nl",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "75",
              "98"
            ]
          },
          {
            "url" : "https://t.co/9Eql7R7cBz",
            "expanded_url" : "http://odissei-soda.nl/#offer",
            "display_url" : "odissei-soda.nl/#offer",
            "indices" : [
              "224",
              "247"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1713908263731802521",
      "id_str" : "1713908265677942842",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1713908265677942842",
      "in_reply_to_status_id" : "1713908263731802521",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 16 13:22:28 +0000 2023",
      "favorited" : false,
      "full_text" : "👫We hope to see you at the next data drop-in!\n\n🔗Teams link in our webpage: https://t.co/NKkwQa1PGO\n\n👉 Also, remember that if you have more specific, long questions, you can also request a consultation or collaboration. See: https://t.co/9Eql7R7cBz",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1713908263731802521"
          ],
          "editableUntil" : "2023-10-16T14:22:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "269"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1713908261966037302",
      "id_str" : "1713908263731802521",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1713908263731802521",
      "in_reply_to_status_id" : "1713908261966037302",
      "created_at" : "Mon Oct 16 13:22:27 +0000 2023",
      "favorited" : false,
      "full_text" : "🗣💬 The data drop-in format is informal and approachable. Examples of questions:\n\n💡Can this research question be answered with these methods?\n💡My code takes too long to run, what can I do to improve it?\n🚩There's a bug in my code\n💡How can I scrape data from the Internet?",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1713908261966037302"
          ],
          "editableUntil" : "2023-10-16T14:22:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "269"
      ],
      "favorite_count" : "0",
      "id_str" : "1713908261966037302",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1713908261966037302",
      "created_at" : "Mon Oct 16 13:22:27 +0000 2023",
      "favorited" : false,
      "full_text" : "📊❔ Do you have questions regarding data, software, methods or computational social science?\n\n✅ Every third Thursday of the month, you can have your questions answered in the SoDa data drop-in!\n\n👉If you have a question and do not know how to get an answer, just drop-in!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1708788914318671933"
          ],
          "editableUntil" : "2023-10-02T11:19:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/DTD73juNyu",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1702318963089404034",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "269",
              "292"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "292"
      ],
      "favorite_count" : "2",
      "id_str" : "1708788914318671933",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1708788914318671933",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 02 10:19:59 +0000 2023",
      "favorited" : false,
      "full_text" : "The first deadline for the Soda fellowship has passed. Thank you all for the interest, questions and applications! 🙏\n\n➡️If you haven't applied yet, note the next deadline is 31st of December.\n\n💭 This could be a nice time to start thinking about your future application https://t.co/DTD73juNyu",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1706963499270705585"
          ],
          "editableUntil" : "2023-09-27T10:26:26.731Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1706963499270705585",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1706963499270705585",
      "created_at" : "Wed Sep 27 09:26:26 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_SoDa: ‼ The first deadline for applying to the fellowship is the 30th of September ‼\n\nIf you are an early career researcher (re…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1706681373786829017"
          ],
          "editableUntil" : "2023-09-26T15:45:22.774Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "74",
              "87"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1706681373786829017",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1706681373786829017",
      "created_at" : "Tue Sep 26 14:45:22 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: ❗️Only 4 days left to apply for the first deadline of the @ODISSEI_SoDa Fellowship.\n\nThis is a fantastic opportunity for ea…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1704135319535456266"
          ],
          "editableUntil" : "2023-09-19T15:08:16.137Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Angelica Maineri",
            "screen_name" : "AngelicaMaineri",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "89449041",
            "id" : "89449041"
          },
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "121",
              "134"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1704135319535456266",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1704135319535456266",
      "created_at" : "Tue Sep 19 14:08:16 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @AngelicaMaineri: Do you want to start sharing your code and don't know where to start? Check out this short guide by @ODISSEI_SoDa http…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1704125409967903187"
          ],
          "editableUntil" : "2023-09-19T14:28:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/DTD73jvlo2",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1702318963089404034",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "228",
              "251"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "251"
      ],
      "favorite_count" : "2",
      "id_str" : "1704125409967903187",
      "truncated" : false,
      "retweet_count" : "7",
      "id" : "1704125409967903187",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 19 13:28:53 +0000 2023",
      "favorited" : false,
      "full_text" : "‼ The first deadline for applying to the fellowship is the 30th of September ‼\n\nIf you are an early career researcher (recently master's graduate, PhD student, or postdoc), don't miss out on a great opportunity!\n\nApply now!\n\n👇👇 https://t.co/DTD73jvlo2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318978646098298"
          ],
          "editableUntil" : "2023-09-14T14:50:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/EPspMlJRfT",
            "expanded_url" : "https://odissei-data.nl/wp-content/uploads/2023/09/Soda_fellowship_call-2023-2024-1.pdf",
            "display_url" : "odissei-data.nl/wp-content/upl…",
            "indices" : [
              "64",
              "87"
            ]
          },
          {
            "url" : "https://t.co/6aHtPHgCA3",
            "expanded_url" : "https://odissei-data.nl/en/2023/09/social-data-science-fellowship-soda-fellowship/",
            "display_url" : "odissei-data.nl/en/2023/09/soc…",
            "indices" : [
              "101",
              "124"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "171"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318976423112859",
      "id_str" : "1702318978646098298",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318978646098298",
      "in_reply_to_status_id" : "1702318976423112859",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 14 13:50:46 +0000 2023",
      "favorited" : false,
      "full_text" : "If you are interested, see the full call for more info:\n\n➡Call: https://t.co/EPspMlJRfT\n\n➡More info: https://t.co/6aHtPHgCA3\n\nDo not hesitate to contact us with questions!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318976423112859"
          ],
          "editableUntil" : "2023-09-14T14:50:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318974309171651",
      "id_str" : "1702318976423112859",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318976423112859",
      "in_reply_to_status_id" : "1702318974309171651",
      "created_at" : "Thu Sep 14 13:50:46 +0000 2023",
      "favorited" : false,
      "full_text" : "And Nadya, who will work on using register data to target interventions for poverty alleviation, said: ‘This is a great opportunity to work with people who are not only highly competent, but also genuinely invested in your professional development and well-being as a fellow’",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318974309171651"
          ],
          "editableUntil" : "2023-09-14T14:50:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "218"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318972111372680",
      "id_str" : "1702318974309171651",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318974309171651",
      "in_reply_to_status_id" : "1702318972111372680",
      "created_at" : "Thu Sep 14 13:50:45 +0000 2023",
      "favorited" : false,
      "full_text" : "Here’s what a couple of past fellows have said about their experience! Aron, who worked on distributionally semantic models, said: ‘During the entire project, I have learned a lot from my supervisors and my colleagues’",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318972111372680"
          ],
          "editableUntil" : "2023-09-14T14:50:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318969879949707",
      "id_str" : "1702318972111372680",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318972111372680",
      "in_reply_to_status_id" : "1702318969879949707",
      "created_at" : "Thu Sep 14 13:50:45 +0000 2023",
      "favorited" : false,
      "full_text" : "🔙After the fellowship, you can resume your original position – with both a newly completed project and a new set of acquired skills!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318969879949707"
          ],
          "editableUntil" : "2023-09-14T14:50:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "147"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318967594037437",
      "id_str" : "1702318969879949707",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318969879949707",
      "in_reply_to_status_id" : "1702318967594037437",
      "created_at" : "Thu Sep 14 13:50:44 +0000 2023",
      "favorited" : false,
      "full_text" : "❔ In doubt whether your project would fit? Just contact us! We can discuss the fit of the project, together with other details of your application.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318967594037437"
          ],
          "editableUntil" : "2023-09-14T14:50:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "229"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1702318965329170913",
      "id_str" : "1702318967594037437",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1702318967594037437",
      "in_reply_to_status_id" : "1702318965329170913",
      "created_at" : "Thu Sep 14 13:50:44 +0000 2023",
      "favorited" : false,
      "full_text" : "📚The topic of your fellowship should be computationally challenging or data-intensive. Some examples are: creating a high-quality analysis pipeline, a causal analysis with simulation-based robustness checks, software development…",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318965329170913"
          ],
          "editableUntil" : "2023-09-14T14:50:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI SoDa",
            "screen_name" : "ODISSEI_SoDa",
            "indices" : [
              "161",
              "174"
            ],
            "id_str" : "1447908998859079690",
            "id" : "1447908998859079690"
          },
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "200",
              "211"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          },
          {
            "name" : "Methods & Stats UU",
            "screen_name" : "MS_Utrecht",
            "indices" : [
              "236",
              "247"
            ],
            "id_str" : "2419443576",
            "id" : "2419443576"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1702318963089404034",
      "id_str" : "1702318965329170913",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1702318965329170913",
      "in_reply_to_status_id" : "1702318963089404034",
      "created_at" : "Thu Sep 14 13:50:43 +0000 2023",
      "favorited" : false,
      "full_text" : "We offer a fully-paid 3-8 month fellowship. In it, you will:\n✔️ Work on a social science related project\n✔️ Together with an external supervisor and an internal @ODISSEI_SoDa mentor\n✔️ Be part of the @ODISSEI_nl  community and based at @MS_Utrecht",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1702318963089404034"
          ],
          "editableUntil" : "2023-09-14T14:50:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/y8H4dmUx1n",
            "expanded_url" : "https://odissei-soda.nl/fellowship/",
            "display_url" : "odissei-soda.nl/fellowship/",
            "indices" : [
              "205",
              "228"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "230"
      ],
      "favorite_count" : "5",
      "id_str" : "1702318963089404034",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1702318963089404034",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 14 13:50:43 +0000 2023",
      "favorited" : false,
      "full_text" : "📝Do you want to carry out your own social science project? Are you an early career researcher? (recently finished master, PhD candidate or early-career Postdoc)\n\n➡You should check out the SoDa fellowship! https://t.co/y8H4dmUx1n\n🧵",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1701219796296020166"
          ],
          "editableUntil" : "2023-09-11T14:03:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/7I5piCTPO4",
            "expanded_url" : "https://odissei-soda.nl/",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "172",
              "195"
            ]
          },
          {
            "url" : "https://t.co/2aPFpZd6GK",
            "expanded_url" : "https://github.com/eyra/port/wiki",
            "display_url" : "github.com/eyra/port/wiki",
            "indices" : [
              "216",
              "239"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "268"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1701219794773508127",
      "id_str" : "1701219796296020166",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1701219796296020166",
      "in_reply_to_status_id" : "1701219794773508127",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 11 13:03:01 +0000 2023",
      "favorited" : false,
      "full_text" : "We hope you find the blog inspiring!  😀\n\n🔍 It you have a research idea that entails digital trace data, but feel stuck, you can contact us:\n\nSee our website for more info: https://t.co/7I5piCTPO4\n\nAnd also check out https://t.co/2aPFpZd6GK for more ideas and tutorials",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1701219794773508127"
          ],
          "editableUntil" : "2023-09-11T14:03:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "233"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1701219793221648621",
      "id_str" : "1701219794773508127",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1701219794773508127",
      "in_reply_to_status_id" : "1701219793221648621",
      "created_at" : "Mon Sep 11 13:03:00 +0000 2023",
      "favorited" : false,
      "full_text" : "🧩 Additionally, we discuss some challenges that arose in writing a script that converts WhatsApp data into an analyzable data format; how to preserve research subjects' privacy or how to request and obtain explicit subject's consent.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1701219793221648621"
          ],
          "editableUntil" : "2023-09-11T14:03:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/YpB8AWyAUN",
            "expanded_url" : "https://datadonation.eu/",
            "display_url" : "datadonation.eu",
            "indices" : [
              "131",
              "154"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "234"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1701219791501988015",
      "id_str" : "1701219793221648621",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1701219793221648621",
      "in_reply_to_status_id" : "1701219791501988015",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 11 13:03:00 +0000 2023",
      "favorited" : false,
      "full_text" : "In the post, we:\n\n1) 🗺️ Briefly guide you through a general workflow for obtaining and using digital trace data via data donation (https://t.co/YpB8AWyAUN)\n\n2) 💬 Show you how we did this in an application with WhatsApp group-chat data",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1701219791501988015"
          ],
          "editableUntil" : "2023-09-11T14:03:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/fluIsZbRiR",
            "expanded_url" : "https://odissei-soda.nl/tutorials/post-4/",
            "display_url" : "odissei-soda.nl/tutorials/post…",
            "indices" : [
              "213",
              "236"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "239"
      ],
      "favorite_count" : "7",
      "id_str" : "1701219791501988015",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1701219791501988015",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 11 13:03:00 +0000 2023",
      "favorited" : false,
      "full_text" : "📊 Digital trace data is everywhere. For instance, data recorded by platforms like WhatsApp, Instagram, or online sellers.\n\n❓ Ever wondered how to use this data for your own research?\n👉 Check out our new blogpost! https://t.co/fluIsZbRiR\n\n🧵",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1700066933914087768"
          ],
          "editableUntil" : "2023-09-08T09:41:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/wErCsE8zj6",
            "expanded_url" : "http://akademienl.social/@odissei_soda",
            "display_url" : "akademienl.social/@odissei_soda",
            "indices" : [
              "29",
              "52"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1700066933914087768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1700066933914087768",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 08 08:41:57 +0000 2023",
      "favorited" : false,
      "full_text" : "And we are also on Mastodon!\nhttps://t.co/wErCsE8zj6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1700065858381369678"
          ],
          "editableUntil" : "2023-09-08T09:37:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "4",
      "id_str" : "1700065858381369678",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1700065858381369678",
      "created_at" : "Fri Sep 08 08:37:40 +0000 2023",
      "favorited" : false,
      "full_text" : "📰 Quick announcement! Carlos has joined our team as Team assistant. That means that we will be increasing our activity on social media! 📈\n\nSo if you don’t still follow us, we invite you to do it!\n\nStay tuned for social science content, blogposts and other announcements.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103612017971281"
          ],
          "editableUntil" : "2023-08-28T11:13:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/hUf7fWhiuh",
            "expanded_url" : "http://odissei-soda.nl/principles",
            "display_url" : "odissei-soda.nl/principles",
            "indices" : [
              "81",
              "104"
            ]
          },
          {
            "url" : "https://t.co/mKMP5Pim14",
            "expanded_url" : "http://github.com/sodascience",
            "display_url" : "github.com/sodascience",
            "indices" : [
              "150",
              "173"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103610243805512",
      "id_str" : "1696103612017971281",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103612017971281",
      "in_reply_to_status_id" : "1696103610243805512",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:07 +0000 2023",
      "favorited" : false,
      "full_text" : "✔️ We are committed to spread Open Science and Team Science. \n\n🌐 More info here: https://t.co/hUf7fWhiuh\n💻 We aim to make all our projects open here: https://t.co/mKMP5Pim14\n\nIf you think we can help, do get in touch!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103610243805512"
          ],
          "editableUntil" : "2023-08-28T11:13:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "76",
              "87"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/NybMFYgvT5",
            "expanded_url" : "http://odissei-data.nl/",
            "display_url" : "odissei-data.nl",
            "indices" : [
              "158",
              "181"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103608473850324",
      "id_str" : "1696103610243805512",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103610243805512",
      "in_reply_to_status_id" : "1696103608473850324",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:07 +0000 2023",
      "favorited" : false,
      "full_text" : "6) ❔ Is there anything else I need to know?\n\nYes!\n\n✔ We are proudly part of @ODISSEI_nl , a large data infrastructure for Social Sciences in the Netherlands. https://t.co/NybMFYgvT5 \n...",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103608473850324"
          ],
          "editableUntil" : "2023-08-28T11:13:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/k7FuNzrrV1",
            "expanded_url" : "https://odissei-data.nl/en/en-odissei/member-organisations/",
            "display_url" : "odissei-data.nl/en/en-odissei/…",
            "indices" : [
              "146",
              "169"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "246"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103606728949913",
      "id_str" : "1696103608473850324",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103608473850324",
      "in_reply_to_status_id" : "1696103606728949913",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:06 +0000 2023",
      "favorited" : false,
      "full_text" : "5) 💵 How much does it cost?\n\nIf your organization is part of ODISSEI, great news: it's free! 💸💸💸 You can check ODISSEI member organizations here: https://t.co/k7FuNzrrV1\n\nOtherwise, get in contact with us and we will let you know what's possible.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103606728949913"
          ],
          "editableUntil" : "2023-08-28T11:13:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Netherlands eScience Center @akademienl.social",
            "screen_name" : "eScienceCenter",
            "indices" : [
              "108",
              "123"
            ],
            "id_str" : "278980371",
            "id" : "278980371"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/cwygKx8Kp1",
            "expanded_url" : "https://causalpolicy.nl/",
            "display_url" : "causalpolicy.nl",
            "indices" : [
              "151",
              "174"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "174"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1696103605101637650",
      "id_str" : "1696103606728949913",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103606728949913",
      "in_reply_to_status_id" : "1696103605101637650",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:06 +0000 2023",
      "favorited" : false,
      "full_text" : "4) 🎓 Besides, we also give workshops! Some examples:\n\n⌨️ Supercomputing for social scientists together with @eScienceCenter\n📝 Causal impact assessment https://t.co/cwygKx8Kp1",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103605101637650"
          ],
          "editableUntil" : "2023-08-28T11:13:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "168"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103603176415711",
      "id_str" : "1696103605101637650",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103605101637650",
      "in_reply_to_status_id" : "1696103603176415711",
      "created_at" : "Mon Aug 28 10:13:06 +0000 2023",
      "favorited" : false,
      "full_text" : "...use of machine learning techniques to estimate risk of life disadvantage in newborns; analysis of the spread of COVID-19 through social networks...\n\nand much more! 🚀",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103603176415711"
          ],
          "editableUntil" : "2023-08-28T11:13:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "214"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103601532268588",
      "id_str" : "1696103603176415711",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103603176415711",
      "in_reply_to_status_id" : "1696103601532268588",
      "created_at" : "Mon Aug 28 10:13:05 +0000 2023",
      "favorited" : false,
      "full_text" : "📃 Small taste of projects we have worked on: developing of R (e.g., to enrich geolocalized databases) and Python (e.g., for synthetic data generation) packages; policy assesment using causal inference techniques...",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103601532268588"
          ],
          "editableUntil" : "2023-08-28T11:13:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/8i3WsaLypD",
            "expanded_url" : "http://odissei-soda.nl/projects",
            "display_url" : "odissei-soda.nl/projects",
            "indices" : [
              "200",
              "223"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "259"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103599799968067",
      "id_str" : "1696103601532268588",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103601532268588",
      "in_reply_to_status_id" : "1696103599799968067",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:05 +0000 2023",
      "favorited" : false,
      "full_text" : "3) 🤔 What does that mean exactly?\n\nWe work on many different kinds of projects, usually characterized by the use of large, complex datasets or complicated analysis methods. See all our projects here: https://t.co/8i3WsaLypD , or look below for a small taste\n👇",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103599799968067"
          ],
          "editableUntil" : "2023-08-28T11:13:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "259"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103597967085803",
      "id_str" : "1696103599799968067",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103599799968067",
      "in_reply_to_status_id" : "1696103597967085803",
      "created_at" : "Mon Aug 28 10:13:04 +0000 2023",
      "favorited" : false,
      "full_text" : "2) 🔧 How do we support social scientists?\n\nWe help with data acquisition, preprocessing, analysis, interpretation and communication.\n\nAmong others, we do that in the form of short consultations, longer project collaborations, or simple brainstorming sessions.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103597967085803"
          ],
          "editableUntil" : "2023-08-28T11:13:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/k5nFslRZir",
            "expanded_url" : "http://odissei-soda.nl/team",
            "display_url" : "odissei-soda.nl/team",
            "indices" : [
              "240",
              "263"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "263"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696103596171972829",
      "id_str" : "1696103597967085803",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696103597967085803",
      "in_reply_to_status_id" : "1696103596171972829",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:04 +0000 2023",
      "favorited" : false,
      "full_text" : "1) 🧑‍🤝‍🧑 Who are we?\n\nWe are a (small) team of data scientists, statisticians, computational scientists and research engineers. We have a variety of backgrounds from computer science and statistics to psychology and sociology.\n\nLearn more: https://t.co/k5nFslRZir",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696103596171972829"
          ],
          "editableUntil" : "2023-08-28T11:13:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "19",
              "30"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/NKkwQa1PGO",
            "expanded_url" : "http://odissei-soda.nl",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "164",
              "187"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "278"
      ],
      "favorite_count" : "8",
      "id_str" : "1696103596171972829",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1696103596171972829",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 28 10:13:04 +0000 2023",
      "favorited" : false,
      "full_text" : "📢 We are SoDa, the @ODISSEI_NL Social Data Science team based in the Netherlands. We help social scientists in NL with data intensive &amp; computational research: https://t.co/NKkwQa1PGO\n\nBut that tells you little. Who are we, really? What do we do?\n\n🧵 Find out in this thread!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1663848299676270592"
          ],
          "editableUntil" : "2023-05-31T10:32:02.106Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Oisín Ryan",
            "screen_name" : "Oisin_Ryan_",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1173185752093614086",
            "id" : "1173185752093614086"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1663848299676270592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1663848299676270592",
      "created_at" : "Wed May 31 10:02:02 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @Oisin_Ryan_: Had a fantastic time teaching this workshop on methods for estimating causal effects of policy interventions with @ejvanke…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1662071229258383360"
          ],
          "editableUntil" : "2023-05-26T12:50:35.502Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1662071229258383360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1662071229258383360",
      "created_at" : "Fri May 26 12:20:35 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: 🚀Happening now! The ODISSEI @SoDa_nl Team is hosting a workshop on causal effects of policy interventions at Utrecht Univer…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1639228126759624706"
          ],
          "editableUntil" : "2023-03-24T12:00:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jsNj70UYtB",
            "expanded_url" : "https://odissei-soda.nl/traineeship/",
            "display_url" : "odissei-soda.nl/traineeship/",
            "indices" : [
              "153",
              "176"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "176"
      ],
      "favorite_count" : "0",
      "id_str" : "1639228126759624706",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1639228126759624706",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 24 11:30:15 +0000 2023",
      "favorited" : false,
      "full_text" : "Next week (March 30th) we'll have another review round for our traineeship programme! It's not too late to apply for this round!\n\nMore info &amp; apply: https://t.co/jsNj70UYtB",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1638879314883096576"
          ],
          "editableUntil" : "2023-03-23T12:54:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "causalinference",
            "indices" : [
              "116",
              "132"
            ]
          },
          {
            "text" : "rstats",
            "indices" : [
              "210",
              "217"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/f2x70pNCfl",
            "expanded_url" : "https://odissei-data.nl/en/2023/03/soda-team-workshop-causal-impact-assessment/",
            "display_url" : "odissei-data.nl/en/2023/03/sod…",
            "indices" : [
              "252",
              "275"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "9",
      "id_str" : "1638879314883096576",
      "truncated" : false,
      "retweet_count" : "7",
      "id" : "1638879314883096576",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 23 12:24:12 +0000 2023",
      "favorited" : false,
      "full_text" : "📢On May 26th, we will do a workshop on methods for causal impact assessment for social scientists! \n\n📈We will build #causalinference intuition with potential outcomes and immediately put this in practice using #rstats.\n\n🔗More info + registration here: https://t.co/f2x70pNCfl",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1626505459183063042"
          ],
          "editableUntil" : "2023-02-17T09:24:55.136Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1626505459183063042",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1626505459183063042",
      "created_at" : "Fri Feb 17 08:54:55 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: 🚨📢 It is now possible to APPLY to participate in our upcoming SICSS-ODISSEI summer school, to work with Dutch administrativ…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596079740007641088"
          ],
          "editableUntil" : "2022-11-25T10:23:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "33",
              "44"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/jsNj70Vwj9",
            "expanded_url" : "https://odissei-soda.nl/traineeship/",
            "display_url" : "odissei-soda.nl/traineeship/",
            "indices" : [
              "234",
              "257"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1596079740007641088/photo/1",
            "indices" : [
              "258",
              "281"
            ],
            "url" : "https://t.co/FQEnVLo6NC",
            "media_url" : "http://pbs.twimg.com/media/FiZp22dXwAAvHcD.jpg",
            "id_str" : "1596079509001977856",
            "id" : "1596079509001977856",
            "media_url_https" : "https://pbs.twimg.com/media/FiZp22dXwAAvHcD.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "734",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "416",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1253",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/FQEnVLo6NC"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "281"
      ],
      "favorite_count" : "8",
      "id_str" : "1596079740007641088",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1596079740007641088",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 25 09:53:58 +0000 2022",
      "favorited" : false,
      "full_text" : "📢 We have an amazing opportunity @ODISSEI_nl\n which we are really excited to share 📢\n\nAre you an early-career social scientist eager to apply data science to relevant societal problems? Become a 𝗦𝗼𝗗𝗮 𝘁𝗿𝗮𝗶𝗻𝗲𝗲! Please share widely/RT.\n\nhttps://t.co/jsNj70Vwj9 https://t.co/FQEnVLo6NC",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1596079740007641088/photo/1",
            "indices" : [
              "258",
              "281"
            ],
            "url" : "https://t.co/FQEnVLo6NC",
            "media_url" : "http://pbs.twimg.com/media/FiZp22dXwAAvHcD.jpg",
            "id_str" : "1596079509001977856",
            "id" : "1596079509001977856",
            "media_url_https" : "https://pbs.twimg.com/media/FiZp22dXwAAvHcD.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "734",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "416",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1253",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/FQEnVLo6NC"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1583412486690451458"
          ],
          "editableUntil" : "2022-10-21T11:28:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OSF2022NL",
            "indices" : [
              "136",
              "146"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "178",
              "192"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/r4oqnjn1JN",
            "expanded_url" : "https://zenodo.org/record/7234121",
            "display_url" : "zenodo.org/record/7234121",
            "indices" : [
              "148",
              "171"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "222"
      ],
      "favorite_count" : "4",
      "id_str" : "1583412486690451458",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1583412486690451458",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 21 10:58:49 +0000 2022",
      "favorited" : false,
      "full_text" : "We just (finally!) uploaded the materials for the pre-conference workshop on synthetic data at the open science festival last september #OSF2022NL\n\nhttps://t.co/r4oqnjn1JN\n\nwith @ejvankesteren, Raoul Schram and @ThomVolker",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582649430284840962"
          ],
          "editableUntil" : "2022-10-19T08:56:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/7I5piCUnDC",
            "expanded_url" : "https://odissei-soda.nl/",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "157",
              "180"
            ]
          },
          {
            "url" : "https://t.co/RYvn6aLPY6",
            "expanded_url" : "https://twitter.com/ODISSEI_SoDa/status/1582014738988351488",
            "display_url" : "twitter.com/ODISSEI_SoDa/s…",
            "indices" : [
              "181",
              "204"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "204"
      ],
      "favorite_count" : "3",
      "id_str" : "1582649430284840962",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1582649430284840962",
      "possibly_sensitive" : false,
      "created_at" : "Wed Oct 19 08:26:43 +0000 2022",
      "favorited" : false,
      "full_text" : "If you want to know more about this, you can also come to our monthly data drop-in, tomorrow at 16:00 on Teams. \n\nYou can find the teams link on our website https://t.co/7I5piCUnDC https://t.co/RYvn6aLPY6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582014751143391232"
          ],
          "editableUntil" : "2022-10-17T14:54:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "callforproposals",
            "indices" : [
              "38",
              "55"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jsNj70Dn51",
            "expanded_url" : "https://odissei-soda.nl/traineeship/",
            "display_url" : "odissei-soda.nl/traineeship/",
            "indices" : [
              "76",
              "99"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "156"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1582014747553079298",
      "id_str" : "1582014751143391232",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582014751143391232",
      "in_reply_to_status_id" : "1582014747553079298",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 17 14:24:43 +0000 2022",
      "favorited" : false,
      "full_text" : "For more detailed information and the #callforproposals, go to our website: https://t.co/jsNj70Dn51\n\nAnd: do share this with anyone who would be interested!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582014747553079298"
          ],
          "editableUntil" : "2022-10-17T14:54:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1582014744071790592",
      "id_str" : "1582014747553079298",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582014747553079298",
      "in_reply_to_status_id" : "1582014744071790592",
      "created_at" : "Mon Oct 17 14:24:42 +0000 2022",
      "favorited" : false,
      "full_text" : "Basically:\n1) you submit a short project proposal together with a supervisor at an ODISSEI institution\n2) if successful, you become a SoDa team member for 3-8 months to work on that project with us;✨we pay your salary✨\n3) you present your work @ ODISSEI (e.g., the conference)",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582014744071790592"
          ],
          "editableUntil" : "2022-10-17T14:54:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/k7FuNz9Qwr",
            "expanded_url" : "https://odissei-data.nl/en/en-odissei/member-organisations/",
            "display_url" : "odissei-data.nl/en/en-odissei/…",
            "indices" : [
              "253",
              "276"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1582014738988351488",
      "id_str" : "1582014744071790592",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582014744071790592",
      "in_reply_to_status_id" : "1582014738988351488",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 17 14:24:42 +0000 2022",
      "favorited" : false,
      "full_text" : "Who is it for? Early-career social scientists* who want to upgrade their data science related skills. \n\n* PhD candidates, early-career postdocs, pre-PhD researchers who have finished their studies; \nwith substantive supervisor at an ODISSEI member org: https://t.co/k7FuNz9Qwr",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582014738988351488"
          ],
          "editableUntil" : "2022-10-17T14:54:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "33",
              "44"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/jsNj70Dn51",
            "expanded_url" : "https://odissei-soda.nl/traineeship/",
            "display_url" : "odissei-soda.nl/traineeship/",
            "indices" : [
              "209",
              "232"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1582014738988351488/photo/1",
            "indices" : [
              "252",
              "275"
            ],
            "url" : "https://t.co/id9fiIsSIP",
            "media_url" : "http://pbs.twimg.com/media/FfRtfLDWYAUSEDX.jpg",
            "id_str" : "1582009751424098309",
            "id" : "1582009751424098309",
            "media_url_https" : "https://pbs.twimg.com/media/FfRtfLDWYAUSEDX.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "734",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "416",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1253",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/id9fiIsSIP"
          }
        ],
        "hashtags" : [
          {
            "text" : "callforproposals",
            "indices" : [
              "234",
              "251"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "16",
      "id_str" : "1582014738988351488",
      "truncated" : false,
      "retweet_count" : "18",
      "id" : "1582014738988351488",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 17 14:24:40 +0000 2022",
      "favorited" : false,
      "full_text" : "📢 We have an amazing opportunity @ODISSEI_nl which we are really excited to share 📢\n\nAre you an early-career social scientist eager to apply data science to relevant societal problems? Become a 𝗦𝗼𝗗𝗮 𝘁𝗿𝗮𝗶𝗻𝗲𝗲!\n\nhttps://t.co/jsNj70Dn51\n\n#callforproposals https://t.co/id9fiIsSIP",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1582014738988351488/photo/1",
            "indices" : [
              "252",
              "275"
            ],
            "url" : "https://t.co/id9fiIsSIP",
            "media_url" : "http://pbs.twimg.com/media/FfRtfLDWYAUSEDX.jpg",
            "id_str" : "1582009751424098309",
            "id" : "1582009751424098309",
            "media_url_https" : "https://pbs.twimg.com/media/FfRtfLDWYAUSEDX.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "734",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "416",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1253",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/id9fiIsSIP"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1575840077963751424"
          ],
          "editableUntil" : "2022-09-30T13:58:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/7I5piCUnDC",
            "expanded_url" : "https://odissei-soda.nl/",
            "display_url" : "odissei-soda.nl",
            "indices" : [
              "34",
              "57"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1575840077963751424/photo/1",
            "indices" : [
              "240",
              "263"
            ],
            "url" : "https://t.co/YBGIHvDLb1",
            "media_url" : "http://pbs.twimg.com/media/Fd58HlzXkAERloI.jpg",
            "id_str" : "1575833389474746369",
            "id" : "1575833389474746369",
            "media_url_https" : "https://pbs.twimg.com/media/Fd58HlzXkAERloI.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "589",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1006",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/YBGIHvDLb1"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "263"
      ],
      "favorite_count" : "10",
      "id_str" : "1575840077963751424",
      "truncated" : false,
      "retweet_count" : "10",
      "id" : "1575840077963751424",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 30 13:28:46 +0000 2022",
      "favorited" : false,
      "full_text" : "📢 We have a shiny new website! 📢\n\nhttps://t.co/7I5piCUnDC\n\n✅Want to get in contact us? \n✅Find out how we work? \n✅See what kind of projects we do / have done? \n✅See who we are? \n✅Learn about scientific data analysis?\n\nGo to our new website👍 https://t.co/YBGIHvDLb1",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1575840077963751424/photo/1",
            "indices" : [
              "240",
              "263"
            ],
            "url" : "https://t.co/YBGIHvDLb1",
            "media_url" : "http://pbs.twimg.com/media/Fd58HlzXkAERloI.jpg",
            "id_str" : "1575833389474746369",
            "id" : "1575833389474746369",
            "media_url_https" : "https://pbs.twimg.com/media/Fd58HlzXkAERloI.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "589",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1006",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/YBGIHvDLb1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570683751650455554"
          ],
          "editableUntil" : "2022-09-16T08:29:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/U5NXjbMUo6",
            "expanded_url" : "https://twitter.com/ODISSEI_nl/status/1570391716108066816",
            "display_url" : "twitter.com/ODISSEI_nl/sta…",
            "indices" : [
              "140",
              "163"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "163"
      ],
      "favorite_count" : "8",
      "id_str" : "1570683751650455554",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1570683751650455554",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 16 07:59:22 +0000 2022",
      "favorited" : false,
      "full_text" : "Come to the ODISSEI conference! Really cool programme with many nice people!\n\n(and talk to us about your research ideas over free drinks 😉) https://t.co/U5NXjbMUo6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569231747883372545"
          ],
          "editableUntil" : "2022-09-12T08:19:38.268Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "0",
      "id_str" : "1569231747883372545",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569231747883372545",
      "created_at" : "Mon Sep 12 07:49:38 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ejvankesteren: Really proud of this paper, part of a @SoDa_nl collaboration! @ODISSEI_nl",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1565237527619010561"
          ],
          "editableUntil" : "2022-09-01T07:48:01.948Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OSF2022NL",
            "indices" : [
              "32",
              "42"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1565237527619010561",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1565237527619010561",
      "created_at" : "Thu Sep 01 07:18:01 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ejvankesteren: On my way to #OSF2022NL! Together with @ThomVolker and Raoul Schram we will give a workshop on creating synthetic data f…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1550057326035566597"
          ],
          "editableUntil" : "2022-07-21T10:27:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/V0Z3i1RGRj",
            "expanded_url" : "https://odissei-data.nl/en/using-soda/",
            "display_url" : "odissei-data.nl/en/using-soda/",
            "indices" : [
              "187",
              "210"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1550057326035566597/photo/1",
            "indices" : [
              "211",
              "234"
            ],
            "url" : "https://t.co/ySExVdSdWc",
            "media_url" : "http://pbs.twimg.com/media/FYLosDOXoAQMjlI.jpg",
            "id_str" : "1550057065246334980",
            "id" : "1550057065246334980",
            "media_url_https" : "https://pbs.twimg.com/media/FYLosDOXoAQMjlI.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2000",
                "h" : "2000",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ySExVdSdWc"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "234"
      ],
      "favorite_count" : "0",
      "id_str" : "1550057326035566597",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1550057326035566597",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 21 09:57:19 +0000 2022",
      "favorited" : false,
      "full_text" : "It's the third Thursday of the month, that means this afternoon (16:00 - 17:00) we have another SoDa Data Drop-in!\n\nYou can join the drop-in on our website (under \"short consultations\"): https://t.co/V0Z3i1RGRj https://t.co/ySExVdSdWc",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1550057326035566597/photo/1",
            "indices" : [
              "211",
              "234"
            ],
            "url" : "https://t.co/ySExVdSdWc",
            "media_url" : "http://pbs.twimg.com/media/FYLosDOXoAQMjlI.jpg",
            "id_str" : "1550057065246334980",
            "id" : "1550057065246334980",
            "media_url_https" : "https://pbs.twimg.com/media/FYLosDOXoAQMjlI.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2000",
                "h" : "2000",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ySExVdSdWc"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1547873694680199169"
          ],
          "editableUntil" : "2022-07-15T09:50:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Zenodo",
            "screen_name" : "ZENODO_ORG",
            "indices" : [
              "213",
              "224"
            ],
            "id_str" : "1251332575",
            "id" : "1251332575"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/YMuM4YLvoP",
            "expanded_url" : "https://odissei-data.nl/en/2022/06/a-short-practical-guide-for-preparing-and-sharing-your-analysis-code/",
            "display_url" : "odissei-data.nl/en/2022/06/a-s…",
            "indices" : [
              "227",
              "250"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "250"
      ],
      "favorite_count" : "1",
      "id_str" : "1547873694680199169",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1547873694680199169",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 15 09:20:21 +0000 2022",
      "favorited" : false,
      "full_text" : "We often get the question \"how can I make my research project's analysis code openly accessible?\"\n\nTo answer this question, we wrote a short practical guide on how to prepare your code folder and publish it using @ZENODO_ORG.\n\nhttps://t.co/YMuM4YLvoP",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546415194657652738"
          ],
          "editableUntil" : "2022-07-11T09:14:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Lees",
            "screen_name" : "mhlees",
            "indices" : [
              "42",
              "49"
            ],
            "id_str" : "17796685",
            "id" : "17796685"
          },
          {
            "name" : "Willem Boterman",
            "screen_name" : "WillemBoterman",
            "indices" : [
              "56",
              "71"
            ],
            "id_str" : "1858195532",
            "id" : "1858195532"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/BFKEi8KUbw",
            "expanded_url" : "https://www.academictransfer.com/en/314890/post-doc-computational-modelling-of-primary-school-segregation/",
            "display_url" : "academictransfer.com/en/314890/post…",
            "indices" : [
              "149",
              "172"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "172"
      ],
      "favorite_count" : "5",
      "id_str" : "1546415194657652738",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1546415194657652738",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 11 08:44:48 +0000 2022",
      "favorited" : false,
      "full_text" : "Exciting opportunity to work with us (and @mhlees &amp; @WillemBoterman) on computational modelling of primary school choice! \n\nApply by July 26th!\n\nhttps://t.co/BFKEi8KUbw",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1526939511674003458"
          ],
          "editableUntil" : "2022-05-18T15:25:23.404Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1526939511674003458",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1526939511674003458",
      "created_at" : "Wed May 18 14:55:23 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: 📢 Call for Papers for our November Social Science in NL Conference is now ONLINE.\n\nWe are thrilled to have as keynotes Prof…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1526140722730115073"
          ],
          "editableUntil" : "2022-05-16T10:31:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "CBS",
            "screen_name" : "statistiekcbs",
            "indices" : [
              "52",
              "66"
            ],
            "id_str" : "61733587",
            "id" : "61733587"
          },
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "151",
              "162"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1526140722730115073/photo/1",
            "indices" : [
              "187",
              "210"
            ],
            "url" : "https://t.co/ks7QMYsz5w",
            "media_url" : "http://pbs.twimg.com/media/FS3wbQIXwAAwp22.jpg",
            "id_str" : "1526140199725678592",
            "id" : "1526140199725678592",
            "media_url_https" : "https://pbs.twimg.com/media/FS3wbQIXwAAwp22.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "327",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "985",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "577",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ks7QMYsz5w"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "210"
      ],
      "favorite_count" : "6",
      "id_str" : "1526140722730115073",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1526140722730115073",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 16 10:01:17 +0000 2022",
      "favorited" : false,
      "full_text" : "Later today, we're presenting to researchers using  @statistiekcbs microdata on how to improve their data analysis code (with a hint on how to use the @ODISSEI_nl secure supercomputer🖥️) https://t.co/ks7QMYsz5w",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1526140722730115073/photo/1",
            "indices" : [
              "187",
              "210"
            ],
            "url" : "https://t.co/ks7QMYsz5w",
            "media_url" : "http://pbs.twimg.com/media/FS3wbQIXwAAwp22.jpg",
            "id_str" : "1526140199725678592",
            "id" : "1526140199725678592",
            "media_url_https" : "https://pbs.twimg.com/media/FS3wbQIXwAAwp22.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "327",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "985",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "577",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ks7QMYsz5w"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1521501684702318592"
          ],
          "editableUntil" : "2022-05-03T15:47:24.424Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Emery",
            "screen_name" : "DrTomEmery",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1015205255968149504",
            "id" : "1015205255968149504"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1521501684702318592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1521501684702318592",
      "created_at" : "Tue May 03 14:47:24 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @DrTomEmery: 5) SoDA Support: This is also on a rolling basis but you can get support from the @SoDa_nl experts in Computational Social…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1518934626609385473"
          ],
          "editableUntil" : "2022-04-26T13:46:50.081Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "rstats",
            "indices" : [
              "61",
              "68"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          },
          {
            "name" : "SURF-coöperatie",
            "screen_name" : "SURF_NL",
            "indices" : [
              "126",
              "134"
            ],
            "id_str" : "19232850",
            "id" : "19232850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1518934626609385473",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1518934626609385473",
      "created_at" : "Tue Apr 26 12:46:50 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ejvankesteren: Are you a (social) scientist working with #rstats? Is your code running slow? \n\nSign up to the workshop by @SURF_NL &amp; @O…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471283495284737"
          ],
          "editableUntil" : "2022-04-22T12:22:01.895Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471279812681728",
      "id_str" : "1517471283495284737",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471283495284737",
      "in_reply_to_status_id" : "1517471279812681728",
      "created_at" : "Fri Apr 22 11:52:01 +0000 2022",
      "favorited" : false,
      "full_text" : "Application deadline: 7th of May 👍",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471279812681728"
          ],
          "editableUntil" : "2022-04-22T12:22:01.017Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1517471279812681728/photo/1",
            "indices" : [
              "260",
              "283"
            ],
            "url" : "https://t.co/bOe9BAlO0B",
            "media_url" : "http://pbs.twimg.com/media/FQ8jJL6WUAIZTr1.jpg",
            "id_str" : "1517470240170463234",
            "id" : "1517470240170463234",
            "media_url_https" : "https://pbs.twimg.com/media/FQ8jJL6WUAIZTr1.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bOe9BAlO0B"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "283"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471273005334528",
      "id_str" : "1517471279812681728",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471279812681728",
      "in_reply_to_status_id" : "1517471273005334528",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 22 11:52:01 +0000 2022",
      "favorited" : false,
      "full_text" : "We collaborate on a variety of computational social science projects, proposed by researchers from ODISSEI member organisations. We use our computational, statistical, and research engineering skills to answer questions that would otherwise remain unanswered. https://t.co/bOe9BAlO0B",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1517471279812681728/photo/1",
            "indices" : [
              "260",
              "283"
            ],
            "url" : "https://t.co/bOe9BAlO0B",
            "media_url" : "http://pbs.twimg.com/media/FQ8jJL6WUAIZTr1.jpg",
            "id_str" : "1517470240170463234",
            "id" : "1517470240170463234",
            "media_url_https" : "https://pbs.twimg.com/media/FQ8jJL6WUAIZTr1.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bOe9BAlO0B"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471273005334528"
          ],
          "editableUntil" : "2022-04-22T12:21:59.394Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/P5Zmtoefi4",
            "expanded_url" : "https://odissei-data.nl/soda",
            "display_url" : "odissei-data.nl/soda",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471269037527040",
      "id_str" : "1517471273005334528",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471273005334528",
      "in_reply_to_status_id" : "1517471269037527040",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 22 11:51:59 +0000 2022",
      "favorited" : false,
      "full_text" : "The SoDa team (https://t.co/P5Zmtoefi4) exists to support social scientists in research projects that involve a strong data analysis component. The team consists of a small group of researchers and research engineers.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471269037527040"
          ],
          "editableUntil" : "2022-04-22T12:21:58.448Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1517471269037527040/photo/1",
            "indices" : [
              "194",
              "217"
            ],
            "url" : "https://t.co/He9yfG2sR0",
            "media_url" : "http://pbs.twimg.com/media/FQ8isx1WQAASl9P.jpg",
            "id_str" : "1517469752133828608",
            "id" : "1517469752133828608",
            "media_url_https" : "https://pbs.twimg.com/media/FQ8isx1WQAASl9P.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "480",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "847",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1446",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/He9yfG2sR0"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471260703346688",
      "id_str" : "1517471269037527040",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471269037527040",
      "in_reply_to_status_id" : "1517471260703346688",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 22 11:51:58 +0000 2022",
      "favorited" : false,
      "full_text" : "The COMPASS project aims to uncover the dynamics of school choice and resulting patterns of school segregation by assuming a multi-dimensional approach to segregation. Think agent-based models! https://t.co/He9yfG2sR0",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1517471269037527040/photo/1",
            "indices" : [
              "194",
              "217"
            ],
            "url" : "https://t.co/He9yfG2sR0",
            "media_url" : "http://pbs.twimg.com/media/FQ8isx1WQAASl9P.jpg",
            "id_str" : "1517469752133828608",
            "id" : "1517469752133828608",
            "media_url_https" : "https://pbs.twimg.com/media/FQ8isx1WQAASl9P.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "480",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "847",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1446",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/He9yfG2sR0"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471260703346688"
          ],
          "editableUntil" : "2022-04-22T12:21:56.461Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/q6sMusHOcl",
            "expanded_url" : "https://www.compass-project.nl/",
            "display_url" : "compass-project.nl",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471257989681152",
      "id_str" : "1517471260703346688",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471260703346688",
      "in_reply_to_status_id" : "1517471257989681152",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 22 11:51:56 +0000 2022",
      "favorited" : false,
      "full_text" : "COMPASS project: https://t.co/q6sMusHOcl\nThe issue of segregation in education can be examined from both the individual level (e.g., parent surveys, choice analysis, etc.) or from macro-level statistics (e.g., changes in segregation level, region, city or national level).",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471257989681152"
          ],
          "editableUntil" : "2022-04-22T12:21:55.814Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "245"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517471255204618242",
      "id_str" : "1517471257989681152",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517471257989681152",
      "in_reply_to_status_id" : "1517471255204618242",
      "created_at" : "Fri Apr 22 11:51:55 +0000 2022",
      "favorited" : false,
      "full_text" : "It's a great opportunity to do cutting-edge research in Computational Social Science while at the same time contributing to a young data science team &amp; get involved in a wide range of interesting research projects throughout the Netherlands.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517471255204618242"
          ],
          "editableUntil" : "2022-04-22T12:21:55.150Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Utrecht University",
            "screen_name" : "UniUtrecht",
            "indices" : [
              "123",
              "134"
            ],
            "id_str" : "33548291",
            "id" : "33548291"
          },
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "136",
              "150"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          },
          {
            "name" : "Javier Garcia-Bernardo (@javier@mathstodon.xyz)",
            "screen_name" : "javiergb_com",
            "indices" : [
              "157",
              "170"
            ],
            "id_str" : "2872545452",
            "id" : "2872545452"
          },
          {
            "name" : "Willem Boterman",
            "screen_name" : "WillemBoterman",
            "indices" : [
              "228",
              "243"
            ],
            "id_str" : "1858195532",
            "id" : "1858195532"
          },
          {
            "name" : "Michael Lees",
            "screen_name" : "mhlees",
            "indices" : [
              "250",
              "257"
            ],
            "id_str" : "17796685",
            "id" : "17796685"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/thW1B14Ia1",
            "expanded_url" : "https://www.academictransfer.com/en/311824/post-doc-computational-modelling-of-primary-school-segregation/",
            "display_url" : "academictransfer.com/en/311824/post…",
            "indices" : [
              "260",
              "283"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "283"
      ],
      "favorite_count" : "8",
      "id_str" : "1517471255204618242",
      "truncated" : false,
      "retweet_count" : "14",
      "id" : "1517471255204618242",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 22 11:51:55 +0000 2022",
      "favorited" : false,
      "full_text" : "📢Work with us!📢\n\nPostdoc position until December 2024, working on computational social science projects with the SoDa team @UniUtrecht (@ejvankesteren &amp; @javiergb_com), and on the COMPASS project at University of Amsterdam (@WillemBoterman &amp; @mhlees)\n\nhttps://t.co/thW1B14Ia1",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1516327624058052609"
          ],
          "editableUntil" : "2022-04-19T08:37:32.237Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/qUocXVryOM",
            "expanded_url" : "https://odissei-data.nl/calendar/soda-data-drop-in-6/",
            "display_url" : "odissei-data.nl/calendar/soda-…",
            "indices" : [
              "153",
              "176"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "176"
      ],
      "favorite_count" : "3",
      "id_str" : "1516327624058052609",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1516327624058052609",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 19 08:07:32 +0000 2022",
      "favorited" : false,
      "full_text" : "Are you struggling with your data, programming or statistical methods? We can help you in our monthly SoDa drop-in. The next one is on April 21st 4-5pm: https://t.co/qUocXVryOM",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485619085404782602"
          ],
          "editableUntil" : "2022-01-24T15:22:46.085Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "sicss2022",
            "indices" : [
              "68",
              "78"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Emery",
            "screen_name" : "DrTomEmery",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1015205255968149504",
            "id" : "1015205255968149504"
          },
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "30",
              "41"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1485619085404782602",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485619085404782602",
      "created_at" : "Mon Jan 24 14:22:46 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @DrTomEmery: Apply for the @ODISSEI_nl  summer school as part of #sicss2022. An intensive two-week course on using ODISSEI to conduct co…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483004747561029634"
          ],
          "editableUntil" : "2022-01-17T10:14:19.371Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "8",
              "19"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "268"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1483004742427152385",
      "id_str" : "1483004747561029634",
      "in_reply_to_user_id" : "1447908998859079690",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483004747561029634",
      "in_reply_to_status_id" : "1483004742427152385",
      "created_at" : "Mon Jan 17 09:14:19 +0000 2022",
      "favorited" : false,
      "full_text" : "We, the @ODISSEI_nl  Social Data Science (SoDa) team, exist to support social scientists in their research projects. Researchers from ODISSEI member organisations can propose research projects in need of our computational, statistical, and research engineering skills.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ODISSEI_SoDa",
      "in_reply_to_user_id_str" : "1447908998859079690"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483004742427152385"
          ],
          "editableUntil" : "2022-01-17T10:14:18.147Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "119",
              "130"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/DUib8brXMl",
            "expanded_url" : "https://odissei-data.nl/calendar/soda-data-drop-in-3/",
            "display_url" : "odissei-data.nl/calendar/soda-…",
            "indices" : [
              "245",
              "268"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1483004742427152385/photo/1",
            "indices" : [
              "269",
              "292"
            ],
            "url" : "https://t.co/gxh4iJhiCZ",
            "media_url" : "http://pbs.twimg.com/media/FJSwL7QXoAMhm6T.jpg",
            "id_str" : "1483003896243134467",
            "id" : "1483003896243134467",
            "media_url_https" : "https://pbs.twimg.com/media/FJSwL7QXoAMhm6T.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "475",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "475",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/gxh4iJhiCZ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "292"
      ],
      "favorite_count" : "5",
      "id_str" : "1483004742427152385",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1483004742427152385",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 17 09:14:18 +0000 2022",
      "favorited" : false,
      "full_text" : "Do you have technical questions about how to retrieve, analyze or visualize data? We can assist you! Join our informal @ODISSEI_nl SoDa Data Drop-in this Thursday anytime between 16:00 and 17:00 to say hi and see if we can answer your questions https://t.co/DUib8brXMl https://t.co/gxh4iJhiCZ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1483004742427152385/photo/1",
            "indices" : [
              "269",
              "292"
            ],
            "url" : "https://t.co/gxh4iJhiCZ",
            "media_url" : "http://pbs.twimg.com/media/FJSwL7QXoAMhm6T.jpg",
            "id_str" : "1483003896243134467",
            "id" : "1483003896243134467",
            "media_url_https" : "https://pbs.twimg.com/media/FJSwL7QXoAMhm6T.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "475",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "475",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/gxh4iJhiCZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1470512835809656841"
          ],
          "editableUntil" : "2021-12-13T22:55:55.521Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Daniel Oberski @daob@mastodon.social",
            "screen_name" : "DanielOberski",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "602189400",
            "id" : "602189400"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1470512835809656841",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1470512835809656841",
      "created_at" : "Mon Dec 13 21:55:55 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @DanielOberski: There's an opening for an associate professor (tenured) focusing on social data science at our department. \n\nhttps://t.c…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1469226847166771201"
          ],
          "editableUntil" : "2021-12-10T09:45:51.936Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erasmus University",
            "screen_name" : "erasmusuni",
            "indices" : [
              "117",
              "128"
            ],
            "id_str" : "52693210",
            "id" : "52693210"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/VkI9DExkvm",
            "expanded_url" : "https://odissei-data.nl/en/2021/12/first-aid-for-data-questions-consult-soda-about-computational-calculating-power/",
            "display_url" : "odissei-data.nl/en/2021/12/fir…",
            "indices" : [
              "131",
              "154"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "264"
      ],
      "favorite_count" : "5",
      "id_str" : "1469226847166771201",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1469226847166771201",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 10 08:45:51 +0000 2021",
      "favorited" : false,
      "full_text" : "Do you want to read more about how we support researchers? Check out how we assisted Thijs Lindner, PhD candidate at @erasmusuni:  https://t.co/VkI9DExkvm\n\nAre you struggling with data collection, analysis, interpretation or visualization? Feel free to contact us!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1468854408280690688"
          ],
          "editableUntil" : "2021-12-09T09:05:55.586Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Javier Garcia-Bernardo (@javier@mathstodon.xyz)",
            "screen_name" : "javiergb_com",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "2872545452",
            "id" : "2872545452"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1468854408280690688",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1468854408280690688",
      "created_at" : "Thu Dec 09 08:05:55 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @javiergb_com: Are you struggling with your data, programming or statistical methods? We (@SoDa_nl) can help you in our monthly SoDa dro…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1461334593546637312"
          ],
          "editableUntil" : "2021-11-18T15:04:52.042Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Emery",
            "screen_name" : "DrTomEmery",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1015205255968149504",
            "id" : "1015205255968149504"
          },
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "40",
              "51"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1461334593546637312",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1461334593546637312",
      "created_at" : "Thu Nov 18 14:04:52 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @DrTomEmery: It took 4 years to put ⁦@ODISSEI_nl⁩ together and it’s 18 months since we received a large scale grant from NwO. Today, we…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1461334545001820166"
          ],
          "editableUntil" : "2021-11-18T15:04:40.468Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "17",
              "31"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          },
          {
            "name" : "CBS",
            "screen_name" : "statistiekcbs",
            "indices" : [
              "117",
              "131"
            ],
            "id_str" : "61733587",
            "id" : "61733587"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1461334545001820166/photo/1",
            "indices" : [
              "164",
              "187"
            ],
            "url" : "https://t.co/TQXEt7alCI",
            "media_url" : "http://pbs.twimg.com/media/FEe0BIbXoAkHfPK.jpg",
            "id_str" : "1461334535640162313",
            "id" : "1461334535640162313",
            "media_url_https" : "https://pbs.twimg.com/media/FEe0BIbXoAkHfPK.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TQXEt7alCI"
          }
        ],
        "hashtags" : [
          {
            "text" : "ODISSEI2021",
            "indices" : [
              "46",
              "58"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "187"
      ],
      "favorite_count" : "7",
      "id_str" : "1461334545001820166",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1461334545001820166",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 18 14:04:40 +0000 2021",
      "favorited" : false,
      "full_text" : "Our one and only @ejvankesteren presenting at #ODISSEI2021 on how to create efficient pipelines to analyze data from @statistiekcbs using the odissei supercomputer https://t.co/TQXEt7alCI",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SoDa_nl/status/1461334545001820166/photo/1",
            "indices" : [
              "164",
              "187"
            ],
            "url" : "https://t.co/TQXEt7alCI",
            "media_url" : "http://pbs.twimg.com/media/FEe0BIbXoAkHfPK.jpg",
            "id_str" : "1461334535640162313",
            "id" : "1461334535640162313",
            "media_url_https" : "https://pbs.twimg.com/media/FEe0BIbXoAkHfPK.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TQXEt7alCI"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1461009224268406792"
          ],
          "editableUntil" : "2021-11-17T17:31:57.961Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "121",
              "135"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/eO8a1iKHZl",
            "expanded_url" : "https://odissei-data.nl/en/2021/10/odissei-community-conference-2021-programme-and-registration/",
            "display_url" : "odissei-data.nl/en/2021/10/odi…",
            "indices" : [
              "96",
              "119"
            ]
          },
          {
            "url" : "https://t.co/1JHX9p6Anl",
            "expanded_url" : "http://kansenkaart.nl",
            "display_url" : "kansenkaart.nl",
            "indices" : [
              "181",
              "204"
            ]
          },
          {
            "url" : "https://t.co/V0Z3i1RGRj",
            "expanded_url" : "https://odissei-data.nl/en/using-soda/",
            "display_url" : "odissei-data.nl/en/using-soda/",
            "indices" : [
              "239",
              "262"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "262"
      ],
      "favorite_count" : "5",
      "id_str" : "1461009224268406792",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1461009224268406792",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 17 16:31:57 +0000 2021",
      "favorited" : false,
      "full_text" : "We'll be presenting at and attending the ODISSEI conference tomorrow. You can follow it online: https://t.co/eO8a1iKHZl (@ejvankesteren will present at 14:30 on our contribution to https://t.co/1JHX9p6Anl). And check out our new website!: https://t.co/V0Z3i1RGRj",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1451476058482659391"
          ],
          "editableUntil" : "2021-10-22T10:10:34.120Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ODISSEI",
            "screen_name" : "ODISSEI_nl",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "872463189774094337",
            "id" : "872463189774094337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1451476058482659391",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451476058482659391",
      "created_at" : "Fri Oct 22 09:10:34 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @ODISSEI_nl: The programme of our Community Conference 2021 is now online! Read about the topics and speakers on computational social sc…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1451168251443036160"
          ],
          "editableUntil" : "2021-10-21T13:47:27.203Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erik-Jan van Kesteren",
            "screen_name" : "ejvankesteren",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "961336646850490368",
            "id" : "961336646850490368"
          },
          {
            "name" : "Daniel Oberski @daob@mastodon.social",
            "screen_name" : "DanielOberski",
            "indices" : [
              "35",
              "49"
            ],
            "id_str" : "602189400",
            "id" : "602189400"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1451168251443036160",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451168251443036160",
      "created_at" : "Thu Oct 21 12:47:27 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @ejvankesteren: Out today (with @DanielOberski) Flexible Extensions to Structural Equation Models Using Computation Graphs\n\nWe estimate…",
      "lang" : "en"
    }
  }
]