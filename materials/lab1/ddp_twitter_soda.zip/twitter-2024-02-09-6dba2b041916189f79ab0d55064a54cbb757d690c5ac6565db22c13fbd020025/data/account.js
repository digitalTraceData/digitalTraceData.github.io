window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "soda@odissei-data.nl",
      "createdVia" : "oauth:3033300",
      "username" : "ODISSEI_SoDa",
      "accountId" : "1447908998859079690",
      "createdAt" : "2021-10-12T12:56:59.118Z",
      "accountDisplayName" : "ODISSEI SoDa"
    }
  }
]