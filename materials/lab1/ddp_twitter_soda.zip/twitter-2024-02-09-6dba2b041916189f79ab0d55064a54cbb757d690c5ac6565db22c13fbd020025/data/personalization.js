window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "Dutch",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "AI image generation",
            "isDisabled" : false
          },
          {
            "name" : "Adult animation",
            "isDisabled" : false
          },
          {
            "name" : "Andrew Tate",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Arts & culture",
            "isDisabled" : false
          },
          {
            "name" : "Asian cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Big Brother Brasil",
            "isDisabled" : false
          },
          {
            "name" : "Biology",
            "isDisabled" : false
          },
          {
            "name" : "Biotech and biomedical",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance news",
            "isDisabled" : false
          },
          {
            "name" : "CBS",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "CVS Pharmacy",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Childcare",
            "isDisabled" : false
          },
          {
            "name" : "Chris Whitty",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Clint Eastwood",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy TV",
            "isDisabled" : false
          },
          {
            "name" : "Comedy films",
            "isDisabled" : false
          },
          {
            "name" : "Competition shows",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Computer reviews",
            "isDisabled" : false
          },
          {
            "name" : "Credit Cards",
            "isDisabled" : false
          },
          {
            "name" : "Crime drama",
            "isDisabled" : false
          },
          {
            "name" : "Cuisines",
            "isDisabled" : false
          },
          {
            "name" : "Cultural events",
            "isDisabled" : false
          },
          {
            "name" : "Disney",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Drama TV",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Economics",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : false
          },
          {
            "name" : "Eliot Higgins",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Europe",
            "isDisabled" : false
          },
          {
            "name" : "European cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Fiction literature",
            "isDisabled" : false
          },
          {
            "name" : "Fields of study",
            "isDisabled" : false
          },
          {
            "name" : "Filipino cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Fitness",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "France politics",
            "isDisabled" : false
          },
          {
            "name" : "GDP - Gross Domestic Product",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Ghosted: Love Gone Missing",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Global Environmental Issues",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government",
            "isDisabled" : false
          },
          {
            "name" : "Graduate school",
            "isDisabled" : false
          },
          {
            "name" : "Gymnastics",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "Iberian cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Journalism",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Libraries",
            "isDisabled" : false
          },
          {
            "name" : "Lil Yachty",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "McNeil-PPC, Inc",
            "isDisabled" : false
          },
          {
            "name" : "Meta",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Mindful wellness",
            "isDisabled" : false
          },
          {
            "name" : "Minecraft",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "NCIS",
            "isDisabled" : false
          },
          {
            "name" : "Nature",
            "isDisabled" : false
          },
          {
            "name" : "Neuroscience",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "Oil trading",
            "isDisabled" : false
          },
          {
            "name" : "Olympic Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Ongoing news stories",
            "isDisabled" : false
          },
          {
            "name" : "Online gaming",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Other competition",
            "isDisabled" : false
          },
          {
            "name" : "Parenting",
            "isDisabled" : false
          },
          {
            "name" : "Physics",
            "isDisabled" : false
          },
          {
            "name" : "Pilar Alegría",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Psychology",
            "isDisabled" : false
          },
          {
            "name" : "Python",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Retired life",
            "isDisabled" : false
          },
          {
            "name" : "Rom-com films",
            "isDisabled" : false
          },
          {
            "name" : "Sandbox games",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy books",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy films",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi and fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Sexual Misconduct in the U.S.",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Spain political figures",
            "isDisabled" : false
          },
          {
            "name" : "Spain politics",
            "isDisabled" : false
          },
          {
            "name" : "Spanish cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Stanford University",
            "isDisabled" : false
          },
          {
            "name" : "Summer Olympics",
            "isDisabled" : false
          },
          {
            "name" : "Sustainability",
            "isDisabled" : false
          },
          {
            "name" : "Taxes",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "The Simpsons",
            "isDisabled" : false
          },
          {
            "name" : "The Simpsons",
            "isDisabled" : false
          },
          {
            "name" : "The Simpsons",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Virgil Van Dijk",
            "isDisabled" : false
          },
          {
            "name" : "Volodymyr Zelensky",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Web development",
            "isDisabled" : false
          },
          {
            "name" : "WhatsApp",
            "isDisabled" : false
          },
          {
            "name" : "Wine",
            "isDisabled" : false
          },
          {
            "name" : "Work from home",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "Yale University",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@55hapime",
            "@BigoArabia",
            "@BrahmaCerveja",
            "@Budweiser_Br",
            "@CarrefourSaudi",
            "@DineJapan",
            "@FFXVMobile",
            "@GoodLifeBCA",
            "@GuardianTalesJP",
            "@LINEMAN_TH",
            "@MODO_Arg",
            "@Manga_Box",
            "@McDMalaysia",
            "@McDonalds_Uy",
            "@NIKKE_kr",
            "@OnmyojigameJP",
            "@Qoo10_Shopping",
            "@RakutenPay_App",
            "@SkyBet",
            "@SofascoreINT",
            "@StellaArtoisBr_",
            "@TapScannerApp",
            "@Tinder_Japan",
            "@WSJ",
            "@WSJCustom",
            "@Yahoo_JAPAN_PR",
            "@becksbeerbr",
            "@comicdays_team",
            "@cvzpatagoniabr",
            "@eToro",
            "@farfetch",
            "@fgoproject",
            "@flowardCo",
            "@fujitvplus",
            "@genshinimpactkr",
            "@heavenburnsred",
            "@indosatim3",
            "@iriam_official",
            "@kagura_shinomas",
            "@letsvpn",
            "@nanovest_io",
            "@pairs_official",
            "@payfleamarket",
            "@photobookth",
            "@pococha_jp",
            "@pococha_jp_PR",
            "@priconne_redive",
            "@resona_groupapp",
            "@sp_logres",
            "@theScore",
            "@yahoo_shopping"
          ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "BBC News at One",
          "Big Brother Brasil",
          "El Hormiguero 3.0",
          "Kleo",
          "Seven Worlds, One Planet",
          "The Flash",
          "The Lord of the Rings: The Rings of Power",
          "The Simpsons",
          "WWE Monday Night RAW"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          ">50"
        ],
        "birthDate" : ""
      }
    }
  }
]