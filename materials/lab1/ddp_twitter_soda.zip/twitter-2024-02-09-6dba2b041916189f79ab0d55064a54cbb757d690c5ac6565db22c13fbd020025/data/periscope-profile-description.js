window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "We help social scientists with data intensive & computational research. Part of @ODISSEI_nl \n\nInterested in collaborating on a project with us? Contact us!"
    }
  }
]