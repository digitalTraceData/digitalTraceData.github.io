window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2021-11-18T14:02:40.000Z",
      "id" : "258901"
    }
  }
]