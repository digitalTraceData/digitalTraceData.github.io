window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "ODISSEI SoDa",
      "digitsId" : "",
      "username" : "SoDa_nl",
      "twitterId" : "1447908998859079690",
      "id" : "1xnQrgOPPXGKY",
      "twitterScreenName" : "ODISSEI_SoDa",
      "isTwitterUser" : true,
      "createdAt" : "2021-11-18T14:04:57.244967893Z"
    }
  }
]