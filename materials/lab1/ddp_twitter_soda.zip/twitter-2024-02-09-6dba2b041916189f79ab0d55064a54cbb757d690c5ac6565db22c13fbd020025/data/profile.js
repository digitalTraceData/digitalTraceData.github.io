window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "We help social scientists with data intensive & computational research. Part of @ODISSEI_nl \n\nInterested in collaborating on a project with us? Contact us!",
        "website" : "https://t.co/zaTT8cAu3Z",
        "location" : "Utrecht"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1447909586271363080/6-HH6pvz.png",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1447908998859079690/1634043726"
    }
  }
]