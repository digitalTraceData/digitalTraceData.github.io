window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "89449041-1447908998859079690",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1704128487504888068",
            "senderId" : "89449041",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2023-09-19T13:41:07.296Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1704126109787488546",
            "senderId" : "1447908998859079690",
            "recipientId" : "89449041",
            "createdAt" : "2023-09-19T13:31:40.400Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1704125458210795955",
            "senderId" : "1447908998859079690",
            "recipientId" : "89449041",
            "createdAt" : "2023-09-19T13:29:05.053Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1704123891801817587",
            "senderId" : "89449041",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2023-09-19T13:22:51.613Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585937952147922948",
            "senderId" : "89449041",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2022-10-28T10:14:07.780Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585933492126457861",
            "senderId" : "1447908998859079690",
            "recipientId" : "89449041",
            "createdAt" : "2022-10-28T09:56:24.423Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1583442918181937156",
            "senderId" : "89449041",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2022-10-21T12:59:45.370Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1015205255968149504-1447908998859079690",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1700094862370943042",
            "senderId" : "1447908998859079690",
            "recipientId" : "1015205255968149504",
            "createdAt" : "2023-09-08T10:32:56.121Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1700094626449764814",
            "senderId" : "1447908998859079690",
            "recipientId" : "1015205255968149504",
            "createdAt" : "2023-09-08T10:31:59.865Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1700071171394293868",
            "senderId" : "1015205255968149504",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2023-09-08T08:58:47.744Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1700070476456829294",
            "senderId" : "1015205255968149504",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2023-09-08T08:56:02.066Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1447908998859079690-1464836118726291462",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1587764400189997061",
            "senderId" : "1464836118726291462",
            "recipientId" : "1447908998859079690",
            "createdAt" : "2022-11-02T11:11:46.946Z"
          }
        }
      ]
    }
  }
]